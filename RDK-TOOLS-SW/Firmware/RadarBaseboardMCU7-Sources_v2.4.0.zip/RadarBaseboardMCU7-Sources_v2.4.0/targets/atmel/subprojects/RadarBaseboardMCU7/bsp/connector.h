/* ===========================================================================
** Copyright (C) 2021 Infineon Technologies AG
**
** Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
**    this list of conditions and the following disclaimer.
** 2. Redistributions in binary form must reproduce the above copyright
**    notice, this list of conditions and the following disclaimer in the
**    documentation and/or other materials provided with the distribution.
** 3. Neither the name of the copyright holder nor the names of its
**    contributors may be used to endorse or promote products derived from
**    this software without specific prior written permission.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
** CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
** SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
** INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
** CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
** ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
** ===========================================================================
*/

#include <components/radar/ShieldConnectorDefinition.h>
#include <universal/gpio_definitions.h>

ShieldConnectorDefinition_t ShieldConnectorDefinition[] = {
    [0] = {
        .en_ldo      = GPIO_ID('C', 30),
        .ls_spi_oe   = GPIO_ID('D', 24),
        .oc_led      = GPIO_ID('C', 1),
        .oc1         = GPIO_ID('D', 16),
        .oc2         = GPIO_ID('C', 9),
        .oc3         = GPIO_ID('C', 28),
        .oc4         = GPIO_ID('A', 27),
        .oc5         = GPIO_NAME_NONE,
        .ls_gpio_oe  = GPIO_ID('D', 14),
        .ls_gpio_dir = GPIO_ID('D', 18),

        .gpio1 = GPIO_ID('A', 9),
        .gpio2 = GPIO_ID('A', 10),
    },
    [1] = {

        .en_ldo      = GPIO_ID('C', 31),
        .ls_spi_oe   = GPIO_ID('A', 9),
        .oc_led      = GPIO_ID('C', 2),
        .oc1         = GPIO_ID('A', 22),
        .oc2         = GPIO_ID('D', 10),
        .oc3         = GPIO_ID('C', 29),
        .oc4         = GPIO_ID('D', 15),
        .oc5         = GPIO_NAME_NONE,
        .ls_gpio_oe  = GPIO_ID('A', 1),
        .ls_gpio_dir = GPIO_ID('C', 10),

        .gpio1 = GPIO_ID('A', 7),
        .gpio2 = GPIO_ID('A', 2),
    },
};
