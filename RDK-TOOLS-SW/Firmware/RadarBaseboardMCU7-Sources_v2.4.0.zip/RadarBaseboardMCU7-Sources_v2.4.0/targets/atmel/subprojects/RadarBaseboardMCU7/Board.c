/* ===========================================================================
** Copyright (C) 2021 Infineon Technologies AG
**
** Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
**    this list of conditions and the following disclaimer.
** 2. Redistributions in binary form must reproduce the above copyright
**    notice, this list of conditions and the following disclaimer in the
**    documentation and/or other materials provided with the distribution.
** 3. Neither the name of the copyright holder nor the names of its
**    contributors may be used to endorse or promote products derived from
**    this software without specific prior written permission.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
** CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
** SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
** INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
** CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
** ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
** ===========================================================================
*/

#include <PlatformInterfaces.h>
#include <board/Board.h>
#include <bsp/connector.h>
#include <bsp/eeprom.h>
#include <bsp/irq.h>
#include <bsp/leds.h>
#include <bsp/radar.h>

#include <common/typeutils.h>
#include <components/radar/Avian.h>
#include <components/radar/ShieldConnector.h>
#include <impl/Platform.h>
#include <impl/fatal_error.h>
#include <platform/DataAvian.h>

#include <protocol/CommandHandlerRadar.h>
#include <protocol/ProtocolHandler.h>
#include <protocol/RequestHandler.h>
#include <protocol/commands/Commands_IRadar.h>


// this automatically includes the correct implementation of getMac() and getUuid() for the Board
#include <platform/ids/impl/getIds.h>

/****************************************************************************
 * Variable declarations
 ****************************************************************************/
#define BOARD_RADAR_COUNT ARRAY_SIZE(ShieldConnectorDefinition)
static Avian m_radar[BOARD_RADAR_COUNT];
static bool m_radarDetected[BOARD_RADAR_COUNT];

#define DATA_AVIAN_BUFFER_SIZE 196608
static uint8_t m_dataAvianBuffer[DATA_AVIAN_BUFFER_SIZE] __attribute__((aligned(sizeof(uint32_t))));

/****************************************************************************
 * Private methods
 ****************************************************************************/
static void Board_dataMeasurementCallback(void *arg, uint8_t *payload, uint32_t count, uint8_t channel, uint64_t timestamp)
{
    /*
     * Sends 12-bit data samples (packed pairwise into 3 bytes) to upper layer
     */
    const sr_t ret = ProtocolHandler_sendDataFrame(payload, count, channel, timestamp);
    if (ret)
    {
        DataAvian_stop(channel);
        ProtocolHandler_resetSendingDataFrames();
    }
}

/****************************************************************************
 * Public methods implementation
 ****************************************************************************/
void Board_Constructor(void)
{
    // Initialize platform-specifics and generic low-level platform interfaces
    Platform_Constructor();
    DataAvian_Constructor();

    IGpio *gpio = &PlatformGpio;
    ISpi *spi   = &PlatformSpi;
    IData *data = &DataAvian;
    II2c *i2c   = &PlatformI2c;

    // Enable communication interface
    RequestHandler_Constructor(gpio, spi, data, i2c);
    ProtocolHandler_Constructor();
    CommandHandlerRadar_Constructor();


    ShieldConnector_Constructor(gpio, i2c);

    uint8_t shieldCount = 0;
    for (uint8_t shieldId = 0; shieldId < ARRAY_SIZE(ShieldConnectorDefinition); shieldId++)
    {
        const sr_t ret = ShieldConnector_initialize(&ShieldConnectorDefinition[shieldId], shieldId);
        if (ret == E_NOT_POSSIBLE)
        {
            fatal_error(FATAL_ERROR_HARDWARE_CONNECTED_WRONG);
        }
        else if (ret == E_NOT_ALLOWED)
        {
            fatal_error(FATAL_ERROR_HARDWARE_NOT_SUPPORTED);
        }
        else if (ret == E_SUCCESS)
        {
            m_radarDetected[shieldId] = true;
            shieldCount++;

            // TODO: detect shield type - for now BGT is assumed

            Avian_Constructor(&m_radar[shieldId], data, gpio, spi, &BoardRadarConfig[shieldId], &BoardRadarPinsConfig[shieldId]);
            Commands_IRadar_register((IRadar *)&m_radar[shieldId]);
        }
        else
        {
            m_radarDetected[shieldId] = false;
            Commands_IRadar_register(NULL);
        }
    }

    if (shieldCount == 0)
    {
        // do not proceed without a properly connected device
        fatal_error(FATAL_ERROR_HARDWARE_NOT_DETECTED);
    }

    uint8_t *buffer           = m_dataAvianBuffer;
    const uint32_t bufferSize = DATA_AVIAN_BUFFER_SIZE / shieldCount;
    for (uint8_t shieldId = 0; shieldId < ARRAY_SIZE(ShieldConnectorDefinition); shieldId++)
    {
        if (m_radarDetected[shieldId])
        {
            const uint8_t dataIndex = BoardRadarConfig[shieldId].dataIndex;
            DataAvian_setBuffer(dataIndex, buffer, bufferSize);
            buffer += bufferSize;
            DataAvian_registerInterrupt(dataIndex, &BoardIrqPinsConfig[shieldId]);
        }
    }

    // TODO: read UUID - legacy call to refactor: Board_setupMainboardNvm();

    //Register callback function to handle arriving data
    data->registerCallback(Board_dataMeasurementCallback, NULL);
}

void Board_run(void)
{
    // needs to be called for state machines, etc.
    Platform_run();

    DataAvian_run();

    // Check polling communication interfaces for incoming requests.
    ProtocolHandler_run();
}
