/* ===========================================================================
** Copyright (C) 2021 Infineon Technologies AG
**
** Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
**    this list of conditions and the following disclaimer.
** 2. Redistributions in binary form must reproduce the above copyright
**    notice, this list of conditions and the following disclaimer in the
**    documentation and/or other materials provided with the distribution.
** 3. Neither the name of the copyright holder nor the names of its
**    contributors may be used to endorse or promote products derived from
**    this software without specific prior written permission.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
** CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
** SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
** INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
** CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
** ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
** ===========================================================================
*/

#include "PlatformSpi.h"

#include "ConfigurationIsr.h"

/* Here we include qspi.h and spi.h directly without going through asf.h as this avoids some duplicate definitions */
#include <qspi.h>
#include <spi.h>

/******************************************************************************/
/*Macro Definitions ----------------------------------------------------------*/
/******************************************************************************/
#ifndef PLATFORM_SPI_MAX_DEVICES
#define PLATFORM_SPI_MAX_DEVICES 4u
#endif

// Maximum number of bits per Spi-transfer
#define PlatformSpi_MIN_DATA_WIDTH 2u
#define PlatformSpi_MAX_DATA_WIDTH 32u
#define PlatformSpi_MAX_TRANSFER   32768u
//#define PlatformSpi_DATA_TRANSFER_TIMEOUT      TimeConst_100ms // TODO: implement timeouts within transfer functions

// SPI/QSPI Macros Definition
#define MIN_DELAY_QCS         0
#define TXDELAY               0  // 0x40
#define SPI_NBITS_CALC_SHIFT  4  // To calculate number of bits from word size
#define QSPI_NBITS_CALC_SHIFT 8  // To calculate number of bits from word size

/******************************************************************************/
/*Private/Public Variables ---------------------------------------------------*/
/******************************************************************************/

static PlatformSpiDefinition_t *m_definition;
static uint8_t m_count                                   = 0;
static volatile uint8_t m_devIdIsr                       = PLATFORM_SPI_MAX_DEVICES;
static bool m_deviceConfigured[PLATFORM_SPI_MAX_DEVICES] = {false};

/******************************************************************************/
/* Function Prototypes ------------------------------------------------------*/
/******************************************************************************/

//static void setup_interface(PlatformSpiDefinition_t *self, uint8_t flags, uint8_t wordSize, uint32_t baudrate);
static sr_t transfer(PlatformSpiDefinition_t *self, const uint8_t *txd, uint8_t *rxd, uint32_t count);
static void drop_rx(PlatformSpiDefinition_t *self);
static void set_word_size(PlatformSpiDefinition_t *self, uint8_t wordSize);

/******************************************************************************/
/* Function Definitions ------------------------------------------------------*/
/******************************************************************************/

static inline void configurePeripheralPin(ioport_pin_t pin, enum ioport_direction dir, ioport_mode_t mode)
{
    ioport_set_pin_dir(pin, dir);
    ioport_set_pin_mode(pin, mode);
    ioport_disable_pin(pin);
}

/* \brief pull CS_N low (protected, only to be used in implementing classes) */
static inline void spi_cs_enable(PlatformSpiDefinition_t *self)
{
    const ioport_pin_t csn = self->pins.csn;
    ioport_set_pin_level(csn, false);
}

/* \brief pull CS_N high (protected, only to be used in implementing classes) */
static inline void spi_cs_disable(PlatformSpiDefinition_t *self)
{
    const ioport_pin_t csn = self->pins.csn;
    ioport_set_pin_level(csn, true);
}

/* \brief acquire lock to spi object to prevent access conflicts
 * (protected, only to be used internally) */
static inline bool spi_try_lock(PlatformSpiDefinition_t *self)
{
    if (self->state.lock == 0)
    {
        self->state.lock++;
        if (self->state.lock == 1)
        {
            return true;
        }
        self->state.lock--;
    }

    return false;
}

static inline void spi_lock(PlatformSpiDefinition_t *self)
{
    while (!spi_try_lock(self))
    {
    }
}

/* \brief release lock to spi object so that other functions can now access it
 * (protected, only to be used internally) */
static inline void spi_unlock(PlatformSpiDefinition_t *self)
{
    self->state.lock--;
}

void setup_qspi(PlatformSpiDefinition_t *self, uint8_t flags, uint8_t wordSize, uint32_t baudrate)
{
    Qspi *qspi = (Qspi *)self->addr.peripheral;

    struct qspi_config_t qspi_config;
    qspi_config.serial_memory_mode          = spi_mode;
    qspi_config.loopback_en                 = false;
    qspi_config.wait_data_for_transfer      = false;
    qspi_config.csmode                      = QSPI_LASTXFER;
    qspi_config.min_delay_qcs               = MIN_DELAY_QCS;
    qspi_config.delay_between_ct            = 0;
    qspi_config.clock_polarity              = (flags & SPI_CPOL);
    qspi_config.clock_phase                 = (flags & SPI_CPHA);
    qspi_config.baudrate                    = baudrate;
    qspi_config.transfer_delay              = TXDELAY;
    qspi_config.scrambling_en               = false;
    qspi_config.scrambling_random_value_dis = false;
    qspi_config.scrambling_user_key         = 0;
    qspi_config.bits_per_transfer           = (uint32_t)(wordSize - 8) << QSPI_NBITS_CALC_SHIFT;
    qspi_initialize(qspi, &qspi_config);
}

void setup_spi(PlatformSpiDefinition_t *self, uint8_t flags, uint8_t wordSize, uint32_t baudrate)
{
    Spi *spi = (Spi *)self->addr.peripheral;

    spi_enable_clock(spi);
    spi_reset(spi);
    spi_set_master_mode(spi);
    spi_disable_mode_fault_detect(spi);
    spi_disable_loopback(spi);
    spi_set_peripheral_chip_select_value(spi, 0);
    spi_set_fixed_peripheral_select(spi);
    spi_disable_peripheral_select_decode(spi);
    spi_set_delay_between_chip_select(spi, MIN_DELAY_QCS);
    spi_set_transfer_delay(spi, 0, TXDELAY, 0);
    set_word_size(self, wordSize);
    spi_set_baudrate_div(spi, 0, (uint8_t)spi_calc_baudrate_div(baudrate, sysclk_get_peripheral_hz()));

    spi_configure_cs_behavior(spi, 0, (uint32_t)SPI_CS_KEEP_LOW);
    spi_set_clock_polarity(spi, 0, (flags & SPI_CPOL));
    //lint -e{730} -e{506}
    spi_set_clock_phase(spi, 0, !(flags & SPI_CPHA));
    spi_enable(spi);
}

static sr_t transfer(PlatformSpiDefinition_t *self, const uint8_t *txd, uint8_t *rxd, uint32_t count)
{
    uint8_t p_pcs;
    Spi *spi = (Spi *)self->addr.peripheral;
    for (uint32_t i = 0; i < count; i++)
    {
        // verified each register and bits matched for QSPI and SPI
        if (spi_write(spi, txd[i], 1, 0) != SPI_OK)
        {
            return E_TIMEOUT;
        }

        uint16_t rx;
        // verified each register and bits matched for QSPI and SPI
        if (spi_read(spi, &rx, &p_pcs) != SPI_OK)
        {
            return E_TIMEOUT;
        }
        rxd[i] = (uint8_t)(rx);
    }

    return E_SUCCESS;
}

// validated spi and qspi same; all registers matching
static void drop_rx(PlatformSpiDefinition_t *self)
{
    Spi *spi = (Spi *)self->addr.peripheral;
    while ((spi->SPI_SR & SPI_SR_RDRF) != 0)
    {
        uint32_t readDummy = spi->SPI_RDR;
        UNUSED(readDummy);
    }
}


// Unify this function
// TODO: Improve Function by checking values at runtime
static void set_word_size(PlatformSpiDefinition_t *self, uint8_t wordSize)
{
    // Check boundary condition for wordsize
    if ((wordSize >= 8) && (wordSize <= 16))
    {
        // Check if self defined for QSPI or SingleSPI
        if (self->peripheral_id == ID_QSPI)
        {
            Qspi *qspi    = (Qspi *)self->addr.peripheral;
            uint32_t bits = (uint32_t)(wordSize - 8) << QSPI_NBITS_CALC_SHIFT;  // to arrive at define QSPI_MR_NBBITS_<wordSize>_BIT
            uint32_t mask = qspi->QSPI_MR & (~QSPI_MR_NBBITS_Msk);
            qspi->QSPI_MR = mask | bits;
        }
        else
        {
            Spi *spi         = (Spi *)self->addr.peripheral;
            uint32_t ul_bits = (uint32_t)((wordSize - 8) << SPI_NBITS_CALC_SHIFT);  // to arrive at define SPI_CSR_BITS_<wordSize>_BIT
            spi_set_bits_per_transfer(spi, 0, ul_bits);
        }
    }
}


void XDMAC_Handler(void)
{
    if (m_devIdIsr >= m_count)
    {
        return;
    }

    PlatformSpiDefinition_t *device = &m_definition[m_devIdIsr];
    uint32_t dma_status             = xdmac_channel_get_interrupt_status(XDMAC, device->dma.rx_dma_channel);

    if (dma_status & XDMAC_CIS_LIS)
    {
        spi_cs_disable(device);
        spi_unlock(device);

        m_devIdIsr = PLATFORM_SPI_MAX_DEVICES;  // reset

        if (device->callback.fn != NULL)
        {
            device->callback.fn(device->callback.context);
        }
        device->callback.fn = NULL;
    }
    else
    {
    }
    if (dma_status & XDMAC_CIS_BIS)
    {
        // do nothing
    }
    if (!(dma_status & (XDMAC_CIS_BIS | XDMAC_CIS_LIS)))
    {
        // do nothing
    }
}

static void dma_transfer(PlatformSpiDefinition_t *self, uint32_t transfer_length, void *rx_data, uint32_t width)
{
    //lint -e{550} -e{830}
    static uint32_t dummy_zero = 0;

    /* drop any leftover content of the SPI RX registers to make sure we don't get any old data in the next transfer */
    drop_rx(self);
    if (transfer_length == 0)
    {
        return;
    }

    spi_cs_enable(self);

    /*lint -e{845} */
    const uint32_t mbr_cfg = XDMAC_CC_TYPE_PER_TRAN |
                             XDMAC_CC_MBSIZE_SINGLE |
                             XDMAC_CC_CSIZE_CHK_1 |
                             width;

    /*lint -e{701} -e{845} */
    const uint32_t tx_mbr_cfg = mbr_cfg |
                                XDMAC_CC_DSYNC_MEM2PER |
                                XDMAC_CC_SIF_AHB_IF0 |
                                XDMAC_CC_DIF_AHB_IF1 |
                                //XDMAC_CC_SAM_INCREMENTED_AM |
                                //XDMAC_CC_SAM_FIXED_AM |
                                XDMAC_CC_DAM_FIXED_AM |
                                XDMAC_CC_PERID(self->dma.tx_dma_hw_id);

    /*lint -e{701} -e{845} */
    const uint32_t rx_mbr_cfg = mbr_cfg |
                                XDMAC_CC_DSYNC_PER2MEM |
                                XDMAC_CC_SIF_AHB_IF1 |
                                XDMAC_CC_DIF_AHB_IF0 |
                                XDMAC_CC_SAM_FIXED_AM |
                                XDMAC_CC_DAM_INCREMENTED_AM |
                                XDMAC_CC_PERID(self->dma.rx_dma_hw_id);


    /* Initialize TX dma */
    self->dma.dma_tx.mbr_nda = 0; /* remnant of linked list struct. no other item */
    self->dma.dma_tx.mbr_ubc = XDMAC_UBC_UBLEN(transfer_length);
    self->dma.dma_tx.mbr_sa  = (uint32_t)&dummy_zero;
    self->dma.dma_tx.mbr_da  = self->addr.tdr;
    /*lint -e{701} -e{845} */
    self->dma.dma_tx.mbr_cfg = tx_mbr_cfg | XDMAC_CC_SAM_FIXED_AM;

    {
        /* Initialize channel config for transmitter */
        xdmac_channel_config_t xdmac_tx_cfg;
        xdmac_tx_cfg.mbr_ubc = 0;
        xdmac_tx_cfg.mbr_sa  = 0;
        xdmac_tx_cfg.mbr_da  = self->addr.tdr;
        xdmac_tx_cfg.mbr_cfg = 0;
        xdmac_tx_cfg.mbr_bc  = 0;
        xdmac_tx_cfg.mbr_ds  = 0;
        xdmac_tx_cfg.mbr_sus = 0;
        xdmac_tx_cfg.mbr_dus = 0;

        xdmac_configure_transfer(XDMAC, self->dma.tx_dma_channel, &xdmac_tx_cfg);
    }

    xdmac_channel_set_descriptor_control(XDMAC, self->dma.tx_dma_channel,
                                         XDMAC_CNDC_NDVIEW_NDV2 |
                                             XDMAC_CNDC_NDE_DSCR_FETCH_EN |
                                             XDMAC_CNDC_NDSUP_SRC_PARAMS_UPDATED);
    xdmac_channel_set_descriptor_addr(XDMAC, self->dma.tx_dma_channel, (uint32_t)(&self->dma.dma_tx), 0);

    /* Initialize RX dma */
    self->dma.dma_rx.mbr_nda = 0; /* remnant of linked list struct */
    self->dma.dma_rx.mbr_ubc = XDMAC_UBC_UBLEN(transfer_length);
    self->dma.dma_rx.mbr_da  = (uint32_t)rx_data;
    self->dma.dma_rx.mbr_sa  = 0;
    self->dma.dma_rx.mbr_cfg = rx_mbr_cfg;

    {
        /* Initialize channel config for receiver */
        xdmac_channel_config_t xdmac_rx_cfg;
        xdmac_rx_cfg.mbr_ubc = 0;
        xdmac_rx_cfg.mbr_da  = 0;
        xdmac_rx_cfg.mbr_sa  = self->addr.rdr;
        xdmac_rx_cfg.mbr_cfg = 0;
        xdmac_rx_cfg.mbr_bc  = 0;
        xdmac_rx_cfg.mbr_ds  = 0;
        xdmac_rx_cfg.mbr_sus = 0;
        xdmac_rx_cfg.mbr_dus = 0;

        xdmac_configure_transfer(XDMAC, self->dma.rx_dma_channel, &xdmac_rx_cfg);
    }

    xdmac_channel_set_descriptor_control(XDMAC, self->dma.rx_dma_channel,
                                         XDMAC_CNDC_NDVIEW_NDV2 |
                                             XDMAC_CNDC_NDE_DSCR_FETCH_EN |
                                             XDMAC_CNDC_NDDUP_DST_PARAMS_UPDATED);
    xdmac_channel_set_descriptor_addr(XDMAC, self->dma.rx_dma_channel, (uint32_t)(&self->dma.dma_rx), 0);

/* Update DCache before DMA transmit */
#ifdef CONF_BOARD_ENABLE_CACHE_AT_INIT
    SCB_CleanInvalidateDCache();
#endif

    /* Start DMA Transfer */
    XDMAC->XDMAC_GE = (XDMAC_GE_EN0 << self->dma.tx_dma_channel) | (XDMAC_GE_EN0 << self->dma.rx_dma_channel);

    //lint -e{550} -e{830}
}

static void dma_transfer8(PlatformSpiDefinition_t *self, uint32_t transfer_length, uint8_t *rx_data)
{
    dma_transfer(self, transfer_length, rx_data, XDMAC_CC_DWIDTH_BYTE);
}

static void dma_transfer16(PlatformSpiDefinition_t *self, uint32_t transfer_length, uint16_t *rx_data)
{
    dma_transfer(self, transfer_length, rx_data, XDMAC_CC_DWIDTH_HALFWORD);
}


/******************************************************************************/
/*Interface Methods Definition -----------------------------------------------*/
/******************************************************************************/

sr_t PlatformSpi_readBurstAsync8(uint8_t devId, uint8_t *bufRead, uint32_t count, void (*cb)(void *), void *arg)
{
    if (devId >= m_count)
    {
        return E_OUT_OF_BOUNDS;
    }
    if (!m_deviceConfigured[devId])
    {
        return E_NOT_CONFIGURED;
    }

    if (count == 0)
    {
        return E_SUCCESS;
    }

    if (m_devIdIsr < PLATFORM_SPI_MAX_DEVICES)
    {
        return E_BUSY;
    }
    m_devIdIsr = devId;

    PlatformSpiDefinition_t *device = &m_definition[devId];

    /* SPI lock is released in DMA IRQ, so no spi_unlock(device) call in this routine */
    if (!spi_try_lock(device))
    {
        m_devIdIsr = PLATFORM_SPI_MAX_DEVICES;
        return E_BUSY;
    }

    device->callback.context = arg;
    device->callback.fn      = cb;

    dma_transfer8(device, count, bufRead);
    return E_SUCCESS;
}

sr_t PlatformSpi_readBurstAsync12(uint8_t devId, uint16_t *bufRead, uint32_t count, void (*cb)(void *), void *arg)
{
    if (devId >= m_count)
    {
        return E_OUT_OF_BOUNDS;
    }
    if (!m_deviceConfigured[devId])
    {
        return E_NOT_CONFIGURED;
    }

    if (count == 0)
    {
        return E_SUCCESS;
    }

    if (m_devIdIsr < PLATFORM_SPI_MAX_DEVICES)
    {
        return E_BUSY;
    }
    m_devIdIsr = devId;

    PlatformSpiDefinition_t *device = &m_definition[devId];

    /* SPI lock is released in DMA IRQ, so no spi_unlock(device) call in this routine */
    if (!spi_try_lock(device))
    {
        m_devIdIsr = PLATFORM_SPI_MAX_DEVICES;
        return E_BUSY;
    }

    device->callback.context = arg;
    device->callback.fn      = cb;

    set_word_size(device, 12);
    dma_transfer16(device, count, bufRead);
    return E_SUCCESS;
}

uint32_t PlatformSpi_getMaxTransfer(void)
{
    return PlatformSpi_MAX_TRANSFER;
}

sr_t PlatformSpi_configure(uint8_t devId, uint8_t flags, uint8_t wordSize, uint32_t speed)
{
    if (devId >= m_count)
    {
        return E_OUT_OF_BOUNDS;
    }

    if ((wordSize < 8) || (wordSize > 16))
    {
        return E_INVALID_PARAMETER;
    }

    PlatformSpiDefinition_t *device = &m_definition[devId];
    if (speed > device->baudrate)
    {
        return E_INVALID_PARAMETER;
    }

    spi_lock(device);
    device->setup_interface(device, flags, wordSize, speed);
    spi_unlock(device);

    m_deviceConfigured[devId] = true;
    return E_SUCCESS;
}

sr_t PlatformSpi_write8(uint8_t devId, uint32_t count, const uint8_t buffer[], bool keepSel)
{
    //Input buffer is NULL -> do not care about incoming data
    return PlatformSpi_transfer8(devId, count, buffer, NULL, keepSel);
}

sr_t PlatformSpi_write16(uint8_t devId, uint32_t count, const uint16_t buffer[], bool keepSel)
{
    //Input buffer is NULL -> do not care about incoming data
    return PlatformSpi_transfer16(devId, count, buffer, NULL, keepSel);
}

sr_t PlatformSpi_write32(uint8_t devId, uint32_t count, const uint32_t buffer[], bool keepSel)
{
    //Input buffer is NULL -> do not care about incoming data
    return PlatformSpi_transfer32(devId, count, buffer, NULL, keepSel);
}

sr_t PlatformSpi_read8(uint8_t devId, uint32_t count, uint8_t buffer[], bool keepSel)
{
    //Output buffer is NULL -> send all ones at every transfer
    return PlatformSpi_transfer8(devId, count, NULL, buffer, keepSel);
}

sr_t PlatformSpi_read16(uint8_t devId, uint32_t count, uint16_t buffer[], bool keepSel)
{
    //Output buffer is NULL -> send all ones at every transfer
    return PlatformSpi_transfer16(devId, count, NULL, buffer, keepSel);
}

sr_t PlatformSpi_read32(uint8_t devId, uint32_t count, uint32_t buffer[], bool keepSel)
{
    //Output buffer is NULL -> send all ones at every transfer
    return PlatformSpi_transfer32(devId, count, NULL, buffer, keepSel);
}


sr_t PlatformSpi_transfer8(uint8_t devId, uint32_t count, const uint8_t bufOut[], uint8_t bufIn[], bool keepSel)
{
    if (devId >= m_count)
    {
        return E_OUT_OF_BOUNDS;
    }
    if (!m_deviceConfigured[devId])
    {
        return E_NOT_CONFIGURED;
    }

    if (count == 0)
    {
        return E_SUCCESS;
    }

    PlatformSpiDefinition_t *device = &m_definition[devId];
    spi_lock(device);

    set_word_size(device, 8);
    spi_cs_enable(device);

    const sr_t ret = transfer(device, bufOut, bufIn, count);

    if (!keepSel)
    {
        spi_cs_disable(device);
    }
    spi_unlock(device);

    return ret;
}

sr_t PlatformSpi_transfer16(uint8_t devId, uint32_t count, const uint16_t bufOut[], uint16_t bufIn[], bool keepSel)
{
    return E_NOT_IMPLEMENTED;
}

sr_t PlatformSpi_transfer32(uint8_t devId, uint32_t count, const uint32_t bufOut[], uint32_t bufIn[], bool keepSel)
{
    return E_NOT_IMPLEMENTED;
}

sr_t PlatformSpi_initialize(PlatformSpiDefinition_t *definition, uint8_t count)
{
    if (count > PLATFORM_SPI_MAX_DEVICES)
    {
        return E_OUT_OF_BOUNDS;
    }

    m_definition = definition;
    m_count      = count;

    /* Initialize and enable DMA controller */
    pmc_enable_periph_clk(ID_XDMAC);

    /*Enable XDMA interrupt */
    NVIC_ClearPendingIRQ(XDMAC_IRQn);
    NVIC_SetPriority(XDMAC_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), ISR_PRIORITY_SPI_IRQ, 0));  // Set interrupt Priority
    NVIC_EnableIRQ(XDMAC_IRQn);

    for (unsigned int i = 0; i < m_count; i++)
    {
        PlatformSpiDefinition_t *device = &m_definition[i];

        pmc_enable_periph_clk(device->peripheral_id);

        /* configure chip select: set io direction and drive CS high */
        ioport_set_pin_mode(device->pins.csn, 0);
        ioport_set_pin_level(device->pins.csn, true);
        ioport_set_pin_dir(device->pins.csn, IOPORT_DIR_OUTPUT);
        ioport_enable_pin(device->pins.csn);

        /* Configure CLK as output (standard SPI configuration) */
        configurePeripheralPin(device->pins.clk, IOPORT_DIR_OUTPUT, device->pins.clk_flags);
        /* Configure DIO1 (MISO) as input (standard SPI configuration) */
        configurePeripheralPin(device->pins.miso, IOPORT_DIR_INPUT, device->pins.miso_flags);
        /* Configure DIO0 as MOSI output (standard SPI configuration) */
        configurePeripheralPin(device->pins.mosi, IOPORT_DIR_OUTPUT, device->pins.mosi_flags);

        xdmac_enable_interrupt(XDMAC, device->dma.rx_dma_channel);
        //xdmac_channel_enable_interrupt(XDMAC, self->rx_dma_channel, XDMAC_CIE_BIE);
        xdmac_channel_enable_interrupt(XDMAC, device->dma.rx_dma_channel, XDMAC_CIE_LIE);
    }

    return E_SUCCESS;
}
