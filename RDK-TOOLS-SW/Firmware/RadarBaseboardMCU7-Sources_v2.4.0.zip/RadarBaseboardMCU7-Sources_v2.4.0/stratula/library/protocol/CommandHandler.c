#include "CommandHandler.h"
#include <universal/protocol/protocol_definitions.h>

#include <stddef.h>

static ICommands *findRegistration(CommandHandler *this, uint8_t bType)
{
    for (uint8_t idx = 0; idx < this->m_occupiedSlots; idx++)
    {
        if (this->m_commandRegistrations[idx].m_bType == bType)
        {
            return (this->m_commandRegistrations + idx);
        }
    }
    return NULL;
}

bool CommandHandler_registerImplementation(CommandHandler *this, const ICommands *commands)
{
    if (this->m_occupiedSlots >= MAX_COMMAND_REGISTRATIONS)
    {
        return false;
    }
    this->m_commandRegistrations[this->m_occupiedSlots++] = *commands;
    return true;
}

uint8_t CommandHandler_write(CommandHandler *this, uint8_t bType, uint8_t bImplementation, uint8_t bId, uint8_t bSubinterface, uint8_t bFunction, uint16_t wLength, const uint8_t *payload)
{
    ICommands *commands = findRegistration(this, bType);
    if (commands == NULL)
    {
        return STATUS_COMMAND_TYPE_INVALID;
    }
    return commands->write(bImplementation, bId, bSubinterface, bFunction, wLength, payload);
}

uint8_t CommandHandler_read(CommandHandler *this, uint8_t bType, uint8_t bImplementation, uint8_t bId, uint8_t bSubinterface, uint8_t bFunction, uint16_t wLength, uint8_t **payload)
{
    ICommands *commands = findRegistration(this, bType);
    if (commands == NULL)
    {
        return STATUS_COMMAND_TYPE_INVALID;
    }
    return commands->read(bImplementation, bId, bSubinterface, bFunction, wLength, payload);
}

uint8_t CommandHandler_transfer(CommandHandler *this, uint8_t bType, uint8_t bImplementation, uint8_t bId, uint8_t bSubinterface, uint8_t bFunction, uint16_t wLengthIn, const uint8_t *payloadIn, uint16_t *wLengthOut, uint8_t **payloadOut)
{
    ICommands *commands = findRegistration(this, bType);
    if (commands == NULL)
    {
        return STATUS_COMMAND_TYPE_INVALID;
    }
    return commands->transfer(bImplementation, bId, bSubinterface, bFunction, wLengthIn, payloadIn, wLengthOut, payloadOut);
}

void CommandHandler_Constructor(CommandHandler *this)
{
    this->m_occupiedSlots = 0;
}
