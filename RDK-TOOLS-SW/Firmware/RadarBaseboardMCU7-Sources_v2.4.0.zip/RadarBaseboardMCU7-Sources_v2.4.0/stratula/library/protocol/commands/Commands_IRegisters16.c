/**
 * \file 	Commands_IRegisters.c
 *
 * \addtogroup      Command_Interface   Command Interface
 *
 * \defgroup        Commands_IRegisters16 IRegisters16 Commands
 * \brief           Radar Sensor interface Commands.
 *
 * @{
 */
#include "Commands_IRegisters16.h"
#include <common/errors.h>
#include <common/serialization.h>
#include <universal/components/subinterfaces/iregisters.h>
#include <universal/protocol/protocol_definitions.h>


uint8_t Commands_IRegisters16_writeBurst(IRegisters16 *registers, uint16_t wLength, const uint8_t *payload)
{
    const uint16_t length = wLength - sizeof(uint16_t);
    if (length % sizeof(uint16_t))
    {
        return STATUS_COMMAND_WLENGTH_INVALID;
    }

    const uint16_t count   = length / sizeof(uint16_t);
    const uint16_t *values = (uint16_t *)(uintptr_t)(payload);
    const uint16_t regAddr = serialToHost16(payload + wLength - 2);
    return registers->writeBurst(registers, regAddr, count, values);
}

uint8_t Commands_IRegisters16_setBits(IRegisters16 *registers, uint16_t wLength, const uint8_t *payload)
{
    if (wLength != (2 * sizeof(uint16_t)))
    {
        return STATUS_COMMAND_WLENGTH_INVALID;
    }

    const uint16_t regAddr = serialToHost16(payload);
    const uint16_t bitmask = serialToHost16(payload + sizeof(regAddr));
    return registers->setBits(registers, regAddr, bitmask);
}

uint8_t Commands_IRegisters16_clearBits(IRegisters16 *registers, uint16_t wLength, const uint8_t *payload)
{
    if (wLength != (2 * sizeof(uint16_t)))
    {
        return STATUS_COMMAND_WLENGTH_INVALID;
    }

    const uint16_t regAddr = serialToHost16(payload);
    const uint16_t bitmask = serialToHost16(payload + sizeof(regAddr));
    return registers->clearBits(registers, regAddr, bitmask);
}

uint8_t Commands_IRegisters16_modifyBits(IRegisters16 *registers, uint16_t wLength, const uint8_t *payload)
{
    if (wLength != (3 * sizeof(uint16_t)))
    {
        return STATUS_COMMAND_WLENGTH_INVALID;
    }

    const uint16_t regAddr      = serialToHost16(payload);
    const uint16_t clearBitmask = serialToHost16(payload + sizeof(regAddr));
    const uint16_t setBitmask   = serialToHost16(payload + sizeof(regAddr) + sizeof(clearBitmask));
    return registers->modifyBits(registers, regAddr, clearBitmask, setBitmask);
}

uint8_t Commands_IRegisters16_readBurst(IRegisters16 *registers, uint16_t wLengthIn, const uint8_t *payloadIn, uint16_t *wLengthOut, uint8_t **payloadOut)
{
    if (wLengthIn != (2 * sizeof(uint16_t)))
    {
        return STATUS_COMMAND_WLENGTH_INVALID;
    }

    const uint16_t regAddr = serialToHost16(payloadIn);
    const uint16_t count   = serialToHost16(payloadIn + sizeof(regAddr));
    *wLengthOut            = count * sizeof(uint16_t);
    uint16_t *values       = (uint16_t *)(uintptr_t)(*payloadOut);
    return registers->readBurst(registers, regAddr, count, values);
}

uint8_t Commands_IRegisters16_read(IRegisters16 *registers, uint8_t bFunction, uint16_t wLength, uint8_t **payload)
{
    switch (bFunction)
    {
        default:
            return STATUS_COMMAND_FUNCTION_INVALID;
            break;
    }
}

uint8_t Commands_IRegisters16_write(IRegisters16 *registers, uint8_t bFunction, uint16_t wLength, const uint8_t *payload)
{
    switch (bFunction)
    {
        case FN_REGISTERS_WRITE_BURST:
            return Commands_IRegisters16_writeBurst(registers, wLength, payload);
            break;
        case FN_REGISTERS_SET_BITS:
            return Commands_IRegisters16_setBits(registers, wLength, payload);
            break;
        case FN_REGISTERS_CLEAR_BITS:
            return Commands_IRegisters16_clearBits(registers, wLength, payload);
            break;
        case FN_REGISTERS_MODIFY_BITS:
            return Commands_IRegisters16_modifyBits(registers, wLength, payload);
            break;
        default:
            return STATUS_COMMAND_FUNCTION_INVALID;
            break;
    }
}

uint8_t Commands_IRegisters16_transfer(IRegisters16 *registers, uint8_t bFunction, uint16_t wLengthIn, const uint8_t *payloadIn, uint16_t *wLengthOut, uint8_t **payloadOut)
{
    switch (bFunction)
    {
        case FN_REGISTERS_READ_BURST:
            return Commands_IRegisters16_readBurst(registers, wLengthIn, payloadIn, wLengthOut, payloadOut);
            break;
        default:
            return STATUS_COMMAND_FUNCTION_INVALID;
            break;
    }
}

/*  @} */
