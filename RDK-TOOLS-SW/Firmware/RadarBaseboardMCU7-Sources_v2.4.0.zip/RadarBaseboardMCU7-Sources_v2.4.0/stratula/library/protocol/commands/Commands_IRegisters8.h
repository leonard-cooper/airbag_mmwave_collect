#ifndef COMMANDS_I_REGISTERS_8_H
#define COMMANDS_I_REGISTERS_8_H 1

#include <components/interfaces/IRegisters8.h>
#include <stdint.h>


/** Writes a burst of Radar register values
 *
 *  @param wLength 1 + length in bytes of payload buffer containing "n" 8-bit Radar register values
 *  @param payload buffer containing "n" 8-bit Radar register values starting at byte 1
 *                 register initial address (8 bit)
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_COMMAND_WLENGTH_INVALID if wLength is not multiple of 2
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegisters8_writeBurst(IRegisters8 *registers, uint16_t wLength, const uint8_t *payload);

/** Set Radar Bits on a given register
 *
 *  @param wLength must be 2
 *  @param payload buffer containing:
 *                 payload[0] = 8-bit register address
 *                 payload[1] = 8-bit mask
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_COMMAND_WLENGTH_INVALID if wLength has incorrect value
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegisters8_setBits(IRegisters8 *registers, uint16_t wLength, const uint8_t *payload);

/** Clear Radar Bits on a given register
 *
 *  @param wLength must be 2
 *  @param payload buffer containing:
 *                 payload[0] = 8-bit register address
 *                 payload[1] = 8-bit mask
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_COMMAND_WLENGTH_INVALID if wLength has incorrect value
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegisters8_clearBits(IRegisters8 *registers, uint16_t wLength, const uint8_t *payload);

/** Modify Radar Bits on a given register
 *
 *  @param wLength must be 3
 *  @param payload buffer containing:
 *                 payload[0] = 8-bit register address
 *                 payload[1] = 8-bit "clear" mask
 *                 payload[2] = 8-bit "set" mask
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_COMMAND_WLENGTH_INVALID if wLength has incorrect value
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegisters8_modifyBits(IRegisters8 *registers, uint16_t wLength, const uint8_t *payload);

/** Reads a burst of Radar register values
 *
 *  @param wLengthIn must be 2
 *  @param payloadIn buffer containing
 *                 payload[0] = register start address
 *                 payload[1] = number of registers to read
 *  @param wLengthOut length in bytes of the return values (number of read registers)
 *  @param payloadOut buffer where Radar register values will be stored
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_COMMAND_WLENGTH_INVALID if wLength is not multiple of 2
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegisters8_readBurst(IRegisters8 *registers, uint16_t wLengthIn, const uint8_t *payloadIn, uint16_t *wLengthOut, uint8_t **payloadOut);

uint8_t Commands_IRegisters8_read(IRegisters8 *registers, uint8_t bFunction, uint16_t wLength, uint8_t **payload);
uint8_t Commands_IRegisters8_write(IRegisters8 *registers, uint8_t bFunction, uint16_t wLength, const uint8_t *payload);
uint8_t Commands_IRegisters8_transfer(IRegisters8 *registers, uint8_t bFunction, uint16_t wLengthIn, const uint8_t *payloadIn, uint16_t *wLengthOut, uint8_t **payloadOut);

#endif /* COMMANDS_I_REGISTERS_8_H */
