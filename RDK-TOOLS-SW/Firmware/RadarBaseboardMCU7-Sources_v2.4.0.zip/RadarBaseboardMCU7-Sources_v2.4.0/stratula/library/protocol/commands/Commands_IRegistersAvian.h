#ifndef COMMANDS_I_REGISTERS_AVIAN_H
#define COMMANDS_I_REGISTERS_AVIAN_H 1

#include <components/interfaces/IRegistersAvian.h>
#include <stdint.h>


/** Writes a burst of register values
 *
 *  @param wLength 1 + length in bytes of payload buffer containing "n" 24-bit Radar register values (stored in 32-bit words)
 *  @param payload buffer containing "n" 24-bit Radar register values distributed as (LSB first)
 *                                        if wLength > 0, n=(wLength-1)/4:
 *                 payload[0 + (n-1)*4] = n-th 24-bit Radar register value, low byte
 *                 payload[1 + (n-1)*4] = n-th 24-bit Radar register value, mid byte
 *                 payload[2 + (n-1)*4] = n-th 24-bit Radar register value, high byte
 *                 payload[3 + (n-1)*4] = padding byte
 *                 payload[n*4 + 1]     = register start address (8 bit)
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_COMMAND_WLENGTH_INVALID if wLength is not multiple of 4 + 1
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegistersAvian_writeBurst(IRegistersAvian *registers, uint16_t wLength, const uint8_t *payload);

/** Set Bits on a given register
 *
 *  @param wLength must be 5
 *  @param payload buffer containing:
 *                 payload[0] = 8-bit register address
 *                 payload[1] = 24-bit mask, low byte
 *                 payload[2] = 24-bit mask, mid byte
 *                 payload[3] = 24-bit mask, high byte
 *                 payload[4] = padding byte
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_COMMAND_WLENGTH_INVALID if wLength has incorrect value
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegistersAvian_setBits(IRegistersAvian *registers, uint16_t wLength, const uint8_t *payload);

/** Clear Bits on a given register
 *
 *  @param wLength must be 5
 *  @param payload buffer containing:
 *                 payload[0] = 8-bit register address
 *                 payload[1] = 24-bit mask, low byte
 *                 payload[2] = 24-bit mask, mid byte
 *                 payload[3] = 24-bit mask, high byte
 *                 payload[4] = padding byte
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_COMMAND_WLENGTH_INVALID if wLength has incorrect value
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegistersAvian_clearBits(IRegistersAvian *registers, uint16_t wLength, const uint8_t *payload);

/** Modify Bits on a given register
 *
 *  @param wLength must be 9
 *  @param payload buffer containing:
 *                 payload[0] = 8-bit register address

 *                 payload[1] = 24-bit "set" mask, low byte
 *                 payload[2] = 24-bit "set" mask, mid byte
 *                 payload[3] = 24-bit "set" mask, high byte
 *                 payload[4] = padding byte
 *
 *                 payload[5] = 24-bit "clear" mask, low byte
 *                 payload[6] = 24-bit "clear" mask, mid byte
 *                 payload[7] = 24-bit "clear" mask, high byte
 *                 payload[8] = padding byte
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_COMMAND_WLENGTH_INVALID if wLength has incorrect value
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegistersAvian_modifyBits(IRegistersAvian *registers, uint16_t wLength, const uint8_t *payload);

/** Reads a burst of Radar register values
 *
 *  @param wLengthIn must be 2
 *  @param payloadIn buffer containing
 *                 payload[0] = register start address (8 bit)
 *                 payload[1] = number of registers to read (8 bit)
 *  @param wLengthOut length in bytes of the return values, i.e. 4 * "n" expected 24-bit return values (stored in 32-bit words)
 *  @param payloadOut buffer where Radar register values will be stored:
 *                                        if wLength > 0, n=wLength/4:
 *                 payload[0 + (n-1)*4] = n-th 24-bit Radar register value, low byte
 *                 payload[1 + (n-1)*4] = n-th 24-bit Radar register value, mid byte
 *                 payload[2 + (n-1)*4] = n-th 24-bit Radar register value, high byte
 *                 payload[3 + (n-1)*4] = padding byte
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_COMMAND_WLENGTH_INVALID if wLengthIn is not 3
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegistersAvian_readBurst(IRegistersAvian *registers, uint16_t wLengthIn, const uint8_t *payloadIn, uint16_t *wLengthOut, uint8_t **payloadOut);

uint8_t Commands_IRegistersAvian_read(IRegistersAvian *registers, uint8_t bFunction, uint16_t wLength, uint8_t **payload);
uint8_t Commands_IRegistersAvian_write(IRegistersAvian *registers, uint8_t bFunction, uint16_t wLength, const uint8_t *payload);
uint8_t Commands_IRegistersAvian_transfer(IRegistersAvian *registers, uint8_t bFunction, uint16_t wLengthIn, const uint8_t *payloadIn, uint16_t *wLengthOut, uint8_t **payloadOut);

#endif /* COMMANDS_I_REGISTERS_AVIAN_H */
