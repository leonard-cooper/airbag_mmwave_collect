/**
 * \file 	Commands_IRegistersAvian.c
 *
 * \addtogroup      Command_Interface   Command Interface
 *
 * \defgroup        Commands_IRegistersAvian IRegistersAvian Commands
 * \brief           Radar Sensor registers interface Commands.
 *
 * @{
 */
#include "Commands_IRegistersAvian.h"
#include <common/errors.h>
#include <common/serialization.h>
#include <universal/components/subinterfaces/iregisters.h>
#include <universal/protocol/protocol_definitions.h>


uint8_t Commands_IRegistersAvian_writeBurst(IRegistersAvian *registers, uint16_t wLength, const uint8_t *payload)
{
    const uint16_t length = wLength - sizeof(uint8_t);
    if ((length % sizeof(uint32_t)) || (length > UINT8_MAX * sizeof(uint32_t)))
    {
        return STATUS_COMMAND_WLENGTH_INVALID;
    }

    const uint8_t count    = length / sizeof(uint32_t);
    const uint32_t *values = (uint32_t *)(uintptr_t)(payload);
    const uint8_t regAddr  = serialToHost8(payload + length);
    return registers->writeBurst(registers, regAddr, count, values);
}

uint8_t Commands_IRegistersAvian_setBits(IRegistersAvian *registers, uint16_t wLength, const uint8_t *payload)
{
    if (wLength != sizeof(uint8_t) + sizeof(uint32_t))
    {
        return STATUS_COMMAND_WLENGTH_INVALID;
    }

    const uint8_t regAddr  = serialToHost8(payload);
    const uint32_t bitmask = serialToHost32(payload + sizeof(regAddr));
    return registers->setBits(registers, regAddr, bitmask);
}

uint8_t Commands_IRegistersAvian_clearBits(IRegistersAvian *registers, uint16_t wLength, const uint8_t *payload)
{
    if (wLength != sizeof(uint8_t) + sizeof(uint32_t))
    {
        return STATUS_COMMAND_WLENGTH_INVALID;
    }

    const uint8_t regAddr  = serialToHost8(payload);
    const uint32_t bitmask = serialToHost32(payload + sizeof(regAddr));
    return registers->clearBits(registers, regAddr, bitmask);
}

uint8_t Commands_IRegistersAvian_modifyBits(IRegistersAvian *registers, uint16_t wLength, const uint8_t *payload)
{
    if (wLength != sizeof(uint8_t) + 2 * sizeof(uint32_t))
    {
        return STATUS_COMMAND_WLENGTH_INVALID;
    }

    const uint8_t regAddr       = serialToHost8(payload);
    const uint32_t clearBitmask = serialToHost32(payload + sizeof(regAddr));
    const uint32_t setBitmask   = serialToHost32(payload + sizeof(regAddr) + sizeof(clearBitmask));
    return registers->modifyBits(registers, regAddr, clearBitmask, setBitmask);
}

uint8_t Commands_IRegistersAvian_readBurst(IRegistersAvian *registers, uint16_t wLengthIn, const uint8_t *payloadIn, uint16_t *wLengthOut, uint8_t **payloadOut)
{
    if (wLengthIn != 2 * sizeof(uint8_t))
    {
        return STATUS_COMMAND_WLENGTH_INVALID;
    }

    const uint8_t regAddr = serialToHost8(payloadIn);
    const uint8_t count   = serialToHost8(payloadIn + sizeof(regAddr));
    *wLengthOut           = count * sizeof(uint32_t);
    uint32_t *values      = (uint32_t *)(uintptr_t)(*payloadOut);
    return registers->readBurst(registers, regAddr, count, values);
}

uint8_t Commands_IRegistersAvian_read(IRegistersAvian *registers, uint8_t bFunction, uint16_t wLength, uint8_t **payload)
{
    switch (bFunction)
    {
        default:
            return STATUS_COMMAND_FUNCTION_INVALID;
            break;
    }
}

uint8_t Commands_IRegistersAvian_write(IRegistersAvian *registers, uint8_t bFunction, uint16_t wLength, const uint8_t *payload)
{
    switch (bFunction)
    {
        case FN_REGISTERS_WRITE_BURST:
            return Commands_IRegistersAvian_writeBurst(registers, wLength, payload);
            break;
        case FN_REGISTERS_SET_BITS:
            return Commands_IRegistersAvian_setBits(registers, wLength, payload);
            break;
        case FN_REGISTERS_CLEAR_BITS:
            return Commands_IRegistersAvian_clearBits(registers, wLength, payload);
            break;
        case FN_REGISTERS_MODIFY_BITS:
            return Commands_IRegistersAvian_modifyBits(registers, wLength, payload);
            break;
        default:
            return STATUS_COMMAND_FUNCTION_INVALID;
            break;
    }
}

uint8_t Commands_IRegistersAvian_transfer(IRegistersAvian *registers, uint8_t bFunction, uint16_t wLengthIn, const uint8_t *payloadIn, uint16_t *wLengthOut, uint8_t **payloadOut)
{
    switch (bFunction)
    {
        case FN_REGISTERS_READ_BURST:
            return Commands_IRegistersAvian_readBurst(registers, wLengthIn, payloadIn, wLengthOut, payloadOut);
            break;
        default:
            return STATUS_COMMAND_FUNCTION_INVALID;
            break;
    }
}

/*  @} */
