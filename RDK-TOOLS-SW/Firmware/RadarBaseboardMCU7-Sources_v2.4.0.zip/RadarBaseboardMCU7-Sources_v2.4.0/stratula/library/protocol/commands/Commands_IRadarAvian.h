#ifndef COMMANDS_IRADAR_AVIAN_H_
#define COMMANDS_IRADAR_AVIAN_H_ 1

#include <components/interfaces/IRadarAvian.h>
#include <stdint.h>

/** Reads front end device properties.
 *
 *  @param wLength must be sizeof_serialized_IRadarAvianProperties()
 *  @param payload buffer pointer where serialized IRadarAvian_Properties_t will be stored.
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  STATUS_REQUEST_LENGTH_INVALID if wLength is incorrect value
 */
uint8_t Commands_IRadarAvian_getProperties(IRadarAvian *radarAvian, uint16_t wLength, uint8_t **payload);

/** Configures the readout parameters for data which is going to be read from the front end device.
 *
 *  @param wLength must be 8
 *  @param payload buffer containing:
 *                 payload[0] = 32-bit burstPrefix, lowest byte
 *                 payload[1] = 32-bit burstPrefix, 2nd lowest byte
 *                 payload[2] = 32-bit burstPrefix, 3rd lowest byte
 *                 payload[3] = 32-bit burstPrefix, high byte
 *
 *                 payload[4] = 32-bit burstSize, lowest byte
 *                 payload[5] = 32-bit burstSize, 2nd lowest byte
 *                 payload[6] = 32-bit burstSize, 3rd lowest byte
 *                 payload[7] = 32-bit burstSize, high byte
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_REQUEST_LENGTH_INVALID if wLength has incorrect value
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRadarAvian_configureDataReadout(IRadarAvian *radarAvian, uint16_t wLength, const uint8_t *payload);

uint8_t Commands_IRadarAvian_read(IRadarAvian *radarAvian, uint8_t bSubinterface, uint8_t bFunction, uint16_t wLength, uint8_t **payload);
uint8_t Commands_IRadarAvian_write(IRadarAvian *radarAvian, uint8_t bSubinterface, uint8_t bFunction, uint16_t wLength, const uint8_t *payload);
uint8_t Commands_IRadarAvian_transfer(IRadarAvian *radarAvian, uint8_t bSubinterface, uint8_t bFunction, uint16_t wLengthIn, const uint8_t *payloadIn, uint16_t *wLengthOut, uint8_t **payloadOut);

#endif /* COMMANDS_IRADAR_AVIAN_H_ */
