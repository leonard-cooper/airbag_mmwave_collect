/**
 * \file 	Commands_IRegisters.c
 *
 * \addtogroup      Command_Interface   Command Interface
 *
 * \defgroup        Commands_IRegisters8 IRegisters8 Commands
 * \brief           Radar Sensor interface Commands.
 *
 * @{
 */
#include "Commands_IRegisters8.h"
#include <common/errors.h>
#include <universal/components/subinterfaces/iregisters.h>
#include <universal/protocol/protocol_definitions.h>


uint8_t Commands_IRegisters8_writeBurst(IRegisters8 *registers, uint16_t wLength, const uint8_t *payload)
{
    const uint8_t count   = wLength - sizeof(uint8_t);
    const uint8_t *values = payload;
    const uint8_t regAddr = payload[count];
    return registers->writeBurst(registers, regAddr, count, values);
}

uint8_t Commands_IRegisters8_setBits(IRegisters8 *registers, uint16_t wLength, const uint8_t *payload)
{
    if (wLength != (2 * sizeof(uint8_t)))
    {
        return STATUS_COMMAND_WLENGTH_INVALID;
    }

    const uint8_t regAddr = payload[0];
    const uint8_t bitmask = payload[1];
    return registers->setBits(registers, regAddr, bitmask);
}

uint8_t Commands_IRegisters8_clearBits(IRegisters8 *registers, uint16_t wLength, const uint8_t *payload)
{
    if (wLength != (2 * sizeof(uint8_t)))
    {
        return STATUS_COMMAND_WLENGTH_INVALID;
    }

    const uint8_t regAddr = payload[0];
    const uint8_t bitmask = payload[1];
    return registers->clearBits(registers, regAddr, bitmask);
}

uint8_t Commands_IRegisters8_modifyBits(IRegisters8 *registers, uint16_t wLength, const uint8_t *payload)
{
    if (wLength != (3 * sizeof(uint8_t)))
    {
        return STATUS_COMMAND_WLENGTH_INVALID;
    }

    const uint8_t regAddr      = payload[0];
    const uint8_t clearBitmask = payload[1];
    const uint8_t setBitmask   = payload[2];
    return registers->modifyBits(registers, regAddr, clearBitmask, setBitmask);
}

uint8_t Commands_IRegisters8_readBurst(IRegisters8 *registers, uint16_t wLengthIn, const uint8_t *payloadIn, uint16_t *wLengthOut, uint8_t **payloadOut)
{
    if (wLengthIn != (2 * sizeof(uint8_t)))
    {
        return STATUS_COMMAND_WLENGTH_INVALID;
    }
    const uint8_t regAddr = payloadIn[0];
    const uint8_t count   = payloadIn[1];
    uint8_t *values       = *payloadOut;
    *wLengthOut           = count;
    return registers->readBurst(registers, regAddr, count, values);
}

uint8_t Commands_IRegisters8_read(IRegisters8 *registers, uint8_t bFunction, uint16_t wLength, uint8_t **payload)
{
    switch (bFunction)
    {
        default:
            return STATUS_COMMAND_FUNCTION_INVALID;
            break;
    }
}

uint8_t Commands_IRegisters8_write(IRegisters8 *registers, uint8_t bFunction, uint16_t wLength, const uint8_t *payload)
{
    switch (bFunction)
    {
        case FN_REGISTERS_WRITE_BURST:
            return Commands_IRegisters8_writeBurst(registers, wLength, payload);
            break;
        case FN_REGISTERS_SET_BITS:
            return Commands_IRegisters8_setBits(registers, wLength, payload);
            break;
        case FN_REGISTERS_CLEAR_BITS:
            return Commands_IRegisters8_clearBits(registers, wLength, payload);
            break;
        case FN_REGISTERS_MODIFY_BITS:
            return Commands_IRegisters8_modifyBits(registers, wLength, payload);
            break;
        default:
            return STATUS_COMMAND_FUNCTION_INVALID;
            break;
    }
}

uint8_t Commands_IRegisters8_transfer(IRegisters8 *registers, uint8_t bFunction, uint16_t wLengthIn, const uint8_t *payloadIn, uint16_t *wLengthOut, uint8_t **payloadOut)
{
    switch (bFunction)
    {
        case FN_REGISTERS_READ_BURST:
            return Commands_IRegisters8_readBurst(registers, wLengthIn, payloadIn, wLengthOut, payloadOut);
            break;
        default:
            return STATUS_COMMAND_FUNCTION_INVALID;
            break;
    }
}

/*  @} */
