#ifndef COMMANDS_I_REGISTERS_16_H
#define COMMANDS_I_REGISTERS_16_H 1

#include <components/interfaces/IRegisters16.h>
#include <stdint.h>


/** Writes a burst of Radar register values
 *
 *  @param wLength 2 + length in bytes of payload buffer containing "n" 16-bit Radar register values
 *  @param payload buffer containing "n" 16-bit Radar register values distributed as (LSB first)
 *                 register initial address (16 bit)
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_COMMAND_WLENGTH_INVALID if wLength is not multiple of 2
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegisters16_writeBurst(IRegisters16 *registers, uint16_t wLength, const uint8_t *payload);

/** Set Radar Bits on a given register
 *
 *  @param wLength must be 4
 *  @param payload buffer containing:
 *                 payload[0..1] = register address (16 bit)
                   payload[2] = 16-bit mask, low byte
 *                 payload[3] = 16-bit mask, high byte
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_COMMAND_WLENGTH_INVALID if wLength has incorrect value
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegisters16_setBits(IRegisters16 *registers, uint16_t wLength, const uint8_t *payload);

/** Clear Radar Bits on a given register
 *
 *  @param wLength must be 4
 *  @param payload buffer containing:
 *                 payload[0..1] = register address (16 bit)
 *                 payload[2] = 16-bit mask, low byte
 *                 payload[3] = 16-bit mask, high byte
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_COMMAND_WLENGTH_INVALID if wLength has incorrect value
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegisters16_clearBits(IRegisters16 *registers, uint16_t wLength, const uint8_t *payload);

/** Modify Radar Bits on a given register
 *
 *  @param wLength must be 6
 *  @param payload buffer containing:
 *                 payload[0..1] = register address (16 bit)
 *                 payload[2] = 16-bit "clear" mask, low byte
 *                 payload[3] = 16-bit "clear" mask, high byte
 *                 payload[4] = 16-bit "set" mask, low byte
 *                 payload[5] = 16-bit "set" mask, high byte
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_COMMAND_WLENGTH_INVALID if wLength has incorrect value
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegisters16_modifyBits(IRegisters16 *registers, uint16_t wLength, const uint8_t *payload);

/** Reads a burst of Radar register values
 *
 *  @param wLengthIn must be 4
 *  @param payloadIn buffer containing
 *                 payload[0..1] = register start address (16 bit)
 *                 payload[2..3] = number of registers to read (16 bit)
 *  @param wLengthOut length in bytes of the return values (i.e. 2 * "n" expected 16-bit return values)
 *  @param payloadOut buffer (16-bit aligned) where Radar register values will be stored:
 *                                        if wLength > 0, n=wLength/2:
 *                 payload[0 + (n-1)*2] = n-th 16-bit Radar register value, low byte
 *                 payload[1 + (n-1)*2] = n-th 16-bit Radar register value, high byte
 *
 *  @return bStatus STATUS_SUCCESS if parameters were valid and execution successful
 *                  STATUS_COMMAND_WLENGTH_INVALID if wLength is not multiple of 2
 *                  E_INVALID_PARAMETER if id maps to a non existing Radar module
 *                  E_FAILED if parameters were valid but execution failed
 */
uint8_t Commands_IRegisters16_readBurst(IRegisters16 *registers, uint16_t wLengthIn, const uint8_t *payloadIn, uint16_t *wLengthOut, uint8_t **payloadOut);

uint8_t Commands_IRegisters16_read(IRegisters16 *registers, uint8_t bFunction, uint16_t wLength, uint8_t **payload);
uint8_t Commands_IRegisters16_write(IRegisters16 *registers, uint8_t bFunction, uint16_t wLength, const uint8_t *payload);
uint8_t Commands_IRegisters16_transfer(IRegisters16 *registers, uint8_t bFunction, uint16_t wLengthIn, const uint8_t *payloadIn, uint16_t *wLengthOut, uint8_t **payloadOut);

#endif /* COMMANDS_I_REGISTERS_16_H */
