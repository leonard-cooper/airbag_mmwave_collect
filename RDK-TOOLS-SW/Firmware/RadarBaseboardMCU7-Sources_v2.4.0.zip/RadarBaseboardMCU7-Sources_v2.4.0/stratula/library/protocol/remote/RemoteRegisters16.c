#include "RemoteRegisters16.h"

#include <common/serialization.h>
#include <stddef.h>
#include <universal/components/implementations/radar.h>
#include <universal/components/subinterfaces.h>
#include <universal/components/subinterfaces/iregisters.h>
#include <universal/components/types.h>
#include <universal/protocol/protocol_definitions.h>

#define IMPL ((RemoteRegisters16 *)(uintptr_t)this)


static sr_t RemoteRegisters16_vendorWrite(RemoteRegisters16 *this, uint8_t bFunction, uint16_t size, const uint8_t *buf)
{
    const uint16_t wValue = CMD_W_VALUE(COMPONENT_TYPE_RADAR, COMPONENT_IMPL_RADAR_RXS);
    const uint16_t wIndex = CMD_W_INDEX(this->m_id, SUBIF_REGISTERS, bFunction);
    return this->m_bridge->vendorWrite(CMD_COMPONENT, wValue, wIndex, size, buf);
}

static sr_t RemoteRegisters16_vendorTransfer(RemoteRegisters16 *this, uint8_t bFunction, uint16_t sizeIn, const uint8_t *bufIn, uint16_t *sizeOut, uint8_t **bufOut)
{
    const uint16_t wValue = CMD_W_VALUE(COMPONENT_TYPE_RADAR, COMPONENT_IMPL_RADAR_RXS);
    const uint16_t wIndex = CMD_W_INDEX(this->m_id, SUBIF_REGISTERS, bFunction);
    return this->m_bridge->vendorTransfer(CMD_COMPONENT, wValue, wIndex, sizeIn, bufIn, sizeOut, bufOut);
}

static sr_t RemoteRegisters16_read(IRegisters16 *this, uint16_t regAddr, uint16_t *readData)
{
    uint8_t bufIn[4];
    hostToSerial16(bufIn, regAddr);
    hostToSerial16(bufIn + sizeof(regAddr), 1);
    uint16_t sizeOut = sizeof(regAddr);
    uint8_t bufOut[sizeOut];
    uint8_t *payload = bufOut;

    const sr_t result = RemoteRegisters16_vendorTransfer(IMPL, FN_REGISTERS_READ_BURST, 4, bufIn, &sizeOut, &payload);

    *readData = serialToHost16(payload);
    return result;
}

static sr_t RemoteRegisters16_write(IRegisters16 *this, uint16_t regAddr, uint16_t value)
{
    const uint8_t size = sizeof(regAddr) + sizeof(value);
    uint8_t buf[size];
    hostToSerial16(buf, regAddr);
    hostToSerial16(buf + sizeof(regAddr), value);

    return RemoteRegisters16_vendorWrite(IMPL, FN_REGISTERS_WRITE_BURST, size, buf);
}

static sr_t RemoteRegisters16_readBurst(IRegisters16 *this, uint16_t regAddr, uint16_t count, uint16_t values[])
{
    uint8_t bufIn[4];
    hostToSerial16(bufIn, regAddr);
    hostToSerial16(bufIn + sizeof(regAddr), count);
    uint16_t sizeOut = count * sizeof(values[0]);
    uint8_t *payload = (uint8_t *)values;

    return RemoteRegisters16_vendorTransfer(IMPL, FN_REGISTERS_READ_BURST, 4, bufIn, &sizeOut, &payload);
}

static sr_t RemoteRegisters16_writeBurst(IRegisters16 *this, uint16_t regAddr, uint16_t count, const uint16_t values[])
{
    const uint16_t argSize  = sizeof(regAddr);
    const uint16_t dataSize = count * sizeof(values[0]);
    uint8_t buf[argSize + dataSize];
    memcpy(buf, values, dataSize);
    hostToSerial16(buf + dataSize, regAddr);

    return RemoteRegisters16_vendorWrite(IMPL, FN_REGISTERS_WRITE_BURST, argSize + dataSize, buf);
}

static sr_t RemoteRegisters16_writeBatch(IRegisters16 *this, const uint16_t regVals[][2], uint16_t count)
{
    return E_NOT_IMPLEMENTED;
}

static sr_t RemoteRegisters16_setBits(IRegisters16 *this, uint16_t regAddr, uint16_t bitmask)
{
    const uint8_t size = sizeof(regAddr) + sizeof(bitmask);
    uint8_t buf[size];
    hostToSerial16(buf, regAddr);
    hostToSerial16(buf + sizeof(regAddr), bitmask);

    return RemoteRegisters16_vendorWrite(IMPL, FN_REGISTERS_SET_BITS, size, buf);
}

static sr_t RemoteRegisters16_clearBits(IRegisters16 *this, uint16_t regAddr, uint16_t bitmask)
{
    const uint8_t size = sizeof(regAddr) + sizeof(bitmask);
    uint8_t buf[size];
    hostToSerial16(buf, regAddr);
    hostToSerial16(buf + sizeof(regAddr), bitmask);

    return RemoteRegisters16_vendorWrite(IMPL, FN_REGISTERS_CLEAR_BITS, size, buf);
}

static sr_t RemoteRegisters16_modifyBits(IRegisters16 *this, uint16_t regAddr, uint16_t setBitmask, uint16_t clearBitmask)
{
    const uint8_t size = sizeof(regAddr) + sizeof(setBitmask) + sizeof(setBitmask);
    uint8_t buf[size];
    hostToSerial16(buf, regAddr);
    hostToSerial16(buf + sizeof(regAddr), clearBitmask);
    hostToSerial16(buf + sizeof(regAddr) + sizeof(clearBitmask), setBitmask);

    return RemoteRegisters16_vendorWrite(IMPL, FN_REGISTERS_MODIFY_BITS, size, buf);
}

void RemoteRegisters16_Constructor(RemoteRegisters16 *this, IBridgeProtocol *bridge, uint8_t id)
{
    this->m_bridge = bridge;
    this->m_id     = id;

    this->b_IRegisters.read       = RemoteRegisters16_read;
    this->b_IRegisters.write      = RemoteRegisters16_write;
    this->b_IRegisters.readBurst  = RemoteRegisters16_readBurst;
    this->b_IRegisters.writeBurst = RemoteRegisters16_writeBurst;
    this->b_IRegisters.writeBatch = RemoteRegisters16_writeBatch;
    this->b_IRegisters.setBits    = RemoteRegisters16_setBits;
    this->b_IRegisters.clearBits  = RemoteRegisters16_clearBits;
    this->b_IRegisters.modifyBits = RemoteRegisters16_modifyBits;
}
