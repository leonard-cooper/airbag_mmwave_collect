#include "RemoteModuleRadar.h"

#include <common/serialization.h>
#include <common/type_serialization.h>
#include <common/type_serialization_size.h>
#include <impl/fatal_error.h>
#include <stddef.h>
#include <universal/modules/types.h>
#include <universal/modules/types/imoduleradar.h>
#include <universal/protocol/protocol_definitions.h>

#define IMPL ((RemoteModuleRadar *)(uintptr_t)this)


static void RemoteModuleRadar_registerDataCallback(IModule *this, IProcessing_DataCallback dataCallback, void *arg)
{
    return;
}

static sr_t RemoteModuleRadar_getDataProperties(IModuleRadar *this, IDataProperties_t *info)
{
    return E_NOT_IMPLEMENTED;
}

static sr_t RemoteModuleRadar_getRadarInfo(IModuleRadar *this, IProcessingRadarInput_t *info, const IDataProperties_t *dataProperties)
{
    return E_NOT_IMPLEMENTED;
}

static IfxRfe_MmicConfig *RemoteModuleRadar_getConfiguration(IModuleRadar *this)
{
    // E_NOT_IMPLEMENTED;
    return NULL;
}

static IfxRfe_Sequence *RemoteModuleRadar_getSequence(IModuleRadar *this)
{
    // E_NOT_IMPLEMENTED;
    return NULL;
}

static IfxRsp_Stages *RemoteModuleRadar_getProcessingStages(IModuleRadar *this)
{
    // E_NOT_IMPLEMENTED;
    return NULL;
}

static IfxRsp_AntennaCalibration *RemoteModuleRadar_getCalibration(IModuleRadar *this)
{
    // E_NOT_IMPLEMENTED;
    return NULL;
}

static sr_t RemoteModuleRadar_vendorWrite(RemoteModuleRadar *this, uint8_t bFunction, uint16_t size, const uint8_t *buf)
{
    const uint16_t wValue = CMD_W_VALUE(MODULE_TYPE_RADAR, MODULE_IMPL_DEFAULT);
    const uint16_t wIndex = CMD_W_INDEX(this->m_id, SUBIF_DEFAULT, bFunction);
    return this->m_bridge->vendorWrite(CMD_MODULE, wValue, wIndex, size, buf);
}

static sr_t RemoteModuleRadar_setConfiguration(IModuleRadar *this, const IfxRfe_MmicConfig *c)
{

    const size_t size = sizeof_serialized_IfxRfe_MmicConfig();
    uint8_t buf[size];
    hostToSerial_IfxRfe_MmicConfig(buf, c);

    return RemoteModuleRadar_vendorWrite(IMPL, FN_MODULE_RADAR_SET_CONFIG, size, buf);
}

static sr_t RemoteModuleRadar_setSequence(IModuleRadar *this, const IfxRfe_Sequence *s)
{
    const size_t size = sizeof_serialized_IfxRfe_Sequence(s->rampCount);
    uint8_t buf[size];
    uint8_t *rampsBuf = hostToSerial_IfxRfe_Sequence(buf, s);
    hostToSerial_IfxRfe_Ramps(rampsBuf, s->ramps, s->rampCount);

    return RemoteModuleRadar_vendorWrite(IMPL, FN_MODULE_RADAR_SET_SEQUENCE, size, buf);
}

static sr_t RemoteModuleRadar_setProcessingStages(IModuleRadar *this, const IfxRsp_Stages *s)
{
    const size_t size = sizeof_serialized_IfxRsp_Stages();
    uint8_t buf[size];
    hostToSerial_IfxRsp_Stages(buf, s);

    return RemoteModuleRadar_vendorWrite(IMPL, FN_MODULE_RADAR_SET_PROCESSING_STAGES, size, buf);
}

static sr_t RemoteModuleRadar_setCalibration(IModuleRadar *this, const IfxRsp_AntennaCalibration c[2])
{
    return E_NOT_IMPLEMENTED;
}

static sr_t RemoteModuleRadar_configure(IModule *this)
{
    return RemoteModuleRadar_vendorWrite(IMPL, FN_MODULE_RADAR_CONFIGURE, 0, NULL);
}

static sr_t RemoteModuleRadar_reset(IModule *this)
{
    return RemoteModuleRadar_vendorWrite(IMPL, FN_MODULE_RADAR_RESET, 0, NULL);
}

static sr_t RemoteModuleRadar_stopMeasurements(IModule *this)
{
    return RemoteModuleRadar_vendorWrite(IMPL, FN_MODULE_RADAR_STOP_MEASUREMENT, 0, NULL);
}

static sr_t RemoteModuleRadar_startMeasurements(IModule *this, double measurementCycle)
{
    const size_t size = sizeof(measurementCycle);
    uint8_t buf[size];
    memcpy(buf, &measurementCycle, sizeof(measurementCycle));
    return RemoteModuleRadar_vendorWrite(IMPL, FN_MODULE_RADAR_START_MEASUREMENT, size, buf);
}

static sr_t RemoteModuleRadar_doMeasurement(IModule *this)
{
    return RemoteModuleRadar_vendorWrite(IMPL, FN_MODULE_RADAR_DO_MEASUREMENT, 0, NULL);
}

void RemoteModuleRadar_Constructor(RemoteModuleRadar *this, IBridgeProtocol *bridge, uint8_t index, uint8_t radarCount, uint8_t radarStartId, uint8_t processingCount, uint8_t processingStartId)
{
    this->m_bridge          = bridge;
    this->m_id              = index;
    this->m_radarCount      = radarCount;
    this->m_processingCount = processingCount;

    if (radarCount > REMOTE_RADAR_MAX_COUNT)
    {
        fatal_error(0);
    }

    for (uint_fast8_t i = 0; i < radarCount; i++)
    {
        //RemoteRadar_Constructor(&this->m_radar[i], bridge, radarStartId + i);
    }
    for (uint_fast8_t i = 0; i < processingCount; i++)
    {
        RemoteProcessingRadar_Constructor(&this->m_processing[i], bridge, processingStartId + i);
    }

    this->b_IModuleRadar.getDataProperties   = RemoteModuleRadar_getDataProperties;
    this->b_IModuleRadar.getRadarInfo        = RemoteModuleRadar_getRadarInfo;
    this->b_IModuleRadar.getConfiguration    = RemoteModuleRadar_getConfiguration;
    this->b_IModuleRadar.getSequence         = RemoteModuleRadar_getSequence;
    this->b_IModuleRadar.getProcessingStages = RemoteModuleRadar_getProcessingStages;
    this->b_IModuleRadar.getCalibration      = RemoteModuleRadar_getCalibration;

    this->b_IModuleRadar.setConfiguration    = RemoteModuleRadar_setConfiguration;
    this->b_IModuleRadar.setSequence         = RemoteModuleRadar_setSequence;
    this->b_IModuleRadar.setProcessingStages = RemoteModuleRadar_setProcessingStages;
    this->b_IModuleRadar.setCalibration      = RemoteModuleRadar_setCalibration;

    this->b_IModuleRadar.b_IModule.configure            = RemoteModuleRadar_configure;
    this->b_IModuleRadar.b_IModule.reset                = RemoteModuleRadar_reset;
    this->b_IModuleRadar.b_IModule.startMeasurements    = RemoteModuleRadar_startMeasurements;
    this->b_IModuleRadar.b_IModule.stopMeasurements     = RemoteModuleRadar_stopMeasurements;
    this->b_IModuleRadar.b_IModule.doMeasurement        = RemoteModuleRadar_doMeasurement;
    this->b_IModuleRadar.b_IModule.registerDataCallback = RemoteModuleRadar_registerDataCallback;
}
