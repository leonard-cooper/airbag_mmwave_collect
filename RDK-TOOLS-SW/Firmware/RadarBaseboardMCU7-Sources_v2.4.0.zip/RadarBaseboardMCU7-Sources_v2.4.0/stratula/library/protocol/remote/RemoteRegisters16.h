/**
 *
 */
#ifndef REMOTE_REGISTERS_16
#define REMOTE_REGISTERS_16 1

#include <components/interfaces/IRegisters16.h>
#include <platform/interfaces/IBridgeProtocol.h>
#include <stdint.h>

typedef struct _RemoteRegisters16 RemoteRegisters16;

struct _RemoteRegisters16
{
    IRegisters16 b_IRegisters;

    IBridgeProtocol *m_bridge;
    uint8_t m_id;
};

void RemoteRegisters16_Constructor(RemoteRegisters16 *this, IBridgeProtocol *bridge, uint8_t id);

#endif /* REMOTE_REGISTERS_16 */
