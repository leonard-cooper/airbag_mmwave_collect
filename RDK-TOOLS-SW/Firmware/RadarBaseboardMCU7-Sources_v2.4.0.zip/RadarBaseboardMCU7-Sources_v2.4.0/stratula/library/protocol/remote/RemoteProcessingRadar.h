/**
 *
 */
#ifndef REMOTEPROCESSINGRADAR_H
#define REMOTEPROCESSINGRADAR_H 1

#include <platform/interfaces/IBridgeProtocol.h>
#include <platform/interfaces/IProcessingRadar.h>
#include <stdint.h>


typedef struct _RemoteProcessingRadar RemoteProcessingRadar;

struct _RemoteProcessingRadar
{
    IProcessingRadar b_IProcessingRadar;

    IBridgeProtocol *m_bridge;
    uint8_t m_id;
    IfxRsp_Signal m_rawData;
};

void RemoteProcessingRadar_Constructor(RemoteProcessingRadar *this, IBridgeProtocol *bridge, uint8_t id);

#endif /* REMOTEPROCESSINGRADAR_H */
