#include "RemoteProcessingRadar.h"

#include <common/serialization.h>
#include <common/type_serialization.h>
#include <common/type_serialization_size.h>
#include <universal/components/subinterfaces.h>
#include <universal/components/types.h>
#include <universal/components/types/iprocessingradar.h>
#include <universal/protocol/protocol_definitions.h>

#define IMPL ((RemoteProcessingRadar *)(uintptr_t)this)

static sr_t RemoteProcessingRadar_vendorRead(RemoteProcessingRadar *this, uint8_t bFunction, uint16_t size, uint8_t **buf)
{
    const uint16_t wValue = CMD_W_VALUE(COMPONENT_TYPE_PROCESSING_RADAR, COMPONENT_IMPL_DEFAULT);
    const uint16_t wIndex = CMD_W_INDEX(this->m_id, SUBIF_DEFAULT, bFunction);
    return this->m_bridge->vendorRead(CMD_COMPONENT, wValue, wIndex, size, buf);
}

static sr_t RemoteProcessingRadar_vendorWrite(RemoteProcessingRadar *this, uint8_t bFunction, uint16_t size, const uint8_t *buf)
{
    const uint16_t wValue = CMD_W_VALUE(COMPONENT_TYPE_PROCESSING_RADAR, COMPONENT_IMPL_DEFAULT);
    const uint16_t wIndex = CMD_W_INDEX(this->m_id, SUBIF_DEFAULT, bFunction);
    return this->m_bridge->vendorWrite(CMD_COMPONENT, wValue, wIndex, size, buf);
}

static sr_t RemoteProcessingRadar_reinitialize(IProcessingRadar *this)
{
    return RemoteProcessingRadar_vendorWrite(IMPL, FN_PROCESSING_RADAR_REINIT, 0, NULL);
}

static sr_t RemoteProcessingRadar_start(IProcessingRadar *this)
{
    return RemoteProcessingRadar_vendorWrite(IMPL, FN_PROCESSING_RADAR_START, 0, NULL);
}

static bool RemoteProcessingRadar_isBusy(IProcessingRadar *this)
{
    uint8_t buf[1];
    uint8_t *payload = buf;

    const sr_t result = RemoteProcessingRadar_vendorRead(IMPL, FN_PROCESSING_RADAR_IS_BUSY, 1, &payload);

    if (result != E_SUCCESS)
    {
        return true;
    }

    return (*payload != 0);
}

static uint32_t RemoteProcessingRadar_allocateCommonMemory(IProcessingRadar *this, uint32_t size)
{
    return E_NOT_IMPLEMENTED;
}

static sr_t RemoteProcessingRadar_writeConfigRam(IProcessingRadar *this, uint16_t offset, uint16_t count, const uint32_t *ramContent)
{
    //No configuration shall be written while it is busy
    const bool busy = RemoteProcessingRadar_isBusy(this);
    if (busy)
    {
        RETURN_ON_ERROR(RemoteProcessingRadar_reinitialize(this));
    }

    const uint32_t argSize     = sizeof(offset);
    const uint16_t maxDataSize = IMPL->m_bridge->getMaxTransfer() - argSize;
    uint32_t dataSize          = count * sizeof(ramContent[0]);

    while (dataSize > 0)
    {
        uint16_t wLength = (dataSize > maxDataSize) ? maxDataSize : dataSize;
        uint16_t wCount  = wLength / sizeof(ramContent[0]);
        uint8_t buf[wLength + argSize];
        memcpy(buf, ramContent, wLength);
        hostToSerial16(buf + wLength, offset);

        RETURN_ON_ERROR(RemoteProcessingRadar_vendorWrite(IMPL, FN_PROCESSING_RADAR_WRITE_CONFIG_RAM, wLength + argSize, buf));

        offset += wCount;
        ramContent += wCount;
        dataSize -= wLength;
    }
    return E_SUCCESS;
}

static sr_t RemoteProcessingRadar_configure(IProcessingRadar *this, uint8_t dataSource, const IDataProperties_t *dataProperties, const IProcessingRadarInput_t *radarInfo,
                                            const IfxRsp_Stages *stages, const IfxRsp_AntennaCalibration *antennaConfig)
{
    const size_t size = sizeof(dataSource) + sizeof_serialized_IDataProperties() + sizeof_serialized_IProcessingRadarInput() + sizeof_serialized_IfxRsp_Stages() + 2 * sizeof_serialized_IfxRsp_AntennaCalibration();
    uint8_t buf[size];

    uint8_t *offset = buf;
    offset          = hostToSerial(offset, dataSource);
    offset          = hostToSerial_IDataProperties(offset, dataProperties);
    offset          = hostToSerial_IProcessingRadarInput(offset, radarInfo);
    offset          = hostToSerial_IfxRsp_Stages(offset, stages);
    if (antennaConfig != NULL)
    {
        offset = hostToSerial_IfxRsp_AntennaCalibration(offset, &antennaConfig[0]);
        offset = hostToSerial_IfxRsp_AntennaCalibration(offset, &antennaConfig[1]);
    }

    return RemoteProcessingRadar_vendorWrite(IMPL, FN_PROCESSING_RADAR_CONFIGURE, size, buf);
}

static sr_t RemoteProcessingRadar_writeCustomWindowCoefficients(IProcessingRadar *this, uint8_t slotNr, uint16_t offset, uint16_t count, const uint32_t *coefficients)
{
    const uint16_t argSize     = sizeof(slotNr) + sizeof(offset);
    const uint16_t maxDataSize = IMPL->m_bridge->getMaxTransfer() - argSize;
    uint32_t dataSize          = count * sizeof(coefficients[0]);

    while (dataSize > 0)
    {
        uint16_t wLength = (dataSize > maxDataSize) ? maxDataSize : dataSize;
        uint16_t wCount  = wLength / sizeof(coefficients[0]);
        uint8_t buf[wLength + argSize];
        memcpy(buf, coefficients, wLength);
        hostToSerial16(buf + wLength, offset);
        hostToSerial8(buf + wLength + sizeof(offset), slotNr);

        RETURN_ON_ERROR(RemoteProcessingRadar_vendorWrite(IMPL, FN_PROCESSING_RADAR_WRITE_CUSTOM_WINDOW_COEFFICIENTS, wLength + argSize, buf));

        offset += wCount;
        coefficients += wCount;
        dataSize -= wLength;
    }
    return E_SUCCESS;
}

static sr_t RemoteProcessingRadar_getRawData(IProcessingRadar *this, IfxRsp_Signal **data)
{
    const size_t size = sizeof_serialized_IfxRsp_Signal();
    uint8_t buf[size];
    uint8_t *payload = buf;

    const sr_t result = RemoteProcessingRadar_vendorRead(IMPL, FN_PROCESSING_RADAR_GET_RAW_DATA, size, &payload);

    serialToHost_IfxRsp_Signal(buf, &IMPL->m_rawData);
    *data = &IMPL->m_rawData;
    return result;
}

void RemoteProcessingRadar_Constructor(RemoteProcessingRadar *this, IBridgeProtocol *bridge, uint8_t id)
{
    this->b_IProcessingRadar.m_bImplementation = COMPONENT_IMPL_DEFAULT;

    this->m_bridge = bridge;
    this->m_id     = id;

    this->b_IProcessingRadar.reinitialize = RemoteProcessingRadar_reinitialize;
    this->b_IProcessingRadar.configure    = RemoteProcessingRadar_configure;
    this->b_IProcessingRadar.start        = RemoteProcessingRadar_start;

    this->b_IProcessingRadar.writeCustomWindowCoefficients = RemoteProcessingRadar_writeCustomWindowCoefficients;
    this->b_IProcessingRadar.writeConfigRam                = RemoteProcessingRadar_writeConfigRam;
    this->b_IProcessingRadar.isBusy                        = RemoteProcessingRadar_isBusy;
    this->b_IProcessingRadar.allocateCommonMemory          = RemoteProcessingRadar_allocateCommonMemory;

    this->b_IProcessingRadar.getRawData = RemoteProcessingRadar_getRawData;
}
