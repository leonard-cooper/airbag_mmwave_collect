/* ===========================================================================
** Copyright (C) 2021 Infineon Technologies AG
**
** Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are met:
**
** 1. Redistributions of source code must retain the above copyright notice,
**    this list of conditions and the following disclaimer.
** 2. Redistributions in binary form must reproduce the above copyright
**    notice, this list of conditions and the following disclaimer in the
**    documentation and/or other materials provided with the distribution.
** 3. Neither the name of the copyright holder nor the names of its
**    contributors may be used to endorse or promote products derived from
**    this software without specific prior written permission.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
** CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
** SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
** INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
** CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
** ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
** ===========================================================================
*/

#include "ShieldConnector.h"

#include <impl/thread.h>

/******************************************************************************/
/*Private/Public Variables ---------------------------------------------------*/
/******************************************************************************/
static IGpio *m_gpio;
static II2c *m_i2c;

/******************************************************************************/
/*Private Methods Definition -------------------------------------------------*/
/******************************************************************************/

/******************************************************************************/
/*Interface Methods Definition -----------------------------------------------*/
/******************************************************************************/

static sr_t ShieldConnector_detect(const ShieldConnectorDefinition_t *definition, uint8_t connectorId)
{
    m_gpio->configurePin(definition->oc1, GPIO_MODE_INPUT);
    m_gpio->configurePin(definition->oc2, GPIO_MODE_INPUT);

    // needed to detect if shield connected wrong
    for (int i = 0; i < 9; i++)
    {
        m_gpio->configurePin(definition->oc1, GPIO_MODE_OUTPUT_PUSH_PULL);
        this_thread_sleep_for(chrono_milliseconds(1));
        m_gpio->configurePin(definition->oc1, GPIO_MODE_INPUT);
        this_thread_sleep_for(chrono_milliseconds(1));
    }
    /* configure level shifter and ldo enable pins as tristate to make sure we don't accidentally
	* see any signal (except those derived from the non-switched Vdd) on the pins we are going to
	* probe. */
    m_gpio->configurePin(definition->ls_spi_oe, GPIO_MODE_INPUT);
    m_gpio->configurePin(definition->en_ldo, GPIO_MODE_INPUT);

    // configure oc1, oc2 pins as pull-downs
    m_gpio->configurePin(definition->oc1, GPIO_MODE_INPUT_PULL_DOWN);
    m_gpio->configurePin(definition->oc2, GPIO_MODE_INPUT_PULL_DOWN);

    // reset i2c bus associated with this Shield connector
    m_i2c->clearBus(I2C_ADDR(connectorId, 0));
    // configure i2c lines in GPIO mode to read levels
    m_i2c->enableBus(I2C_ADDR(connectorId, 0), false);
    // wait 1ms before reading pin levels
    this_thread_sleep_for(chrono_milliseconds(1));

    uint8_t levels;
    // read levels on i2c pins
    m_i2c->readBus(I2C_ADDR(connectorId, 0), &levels);

    // read levels on oc1, oc2 pins
    bool state;
    m_gpio->getPin(definition->oc1, &state);
    levels |= (state) ? 0x04 : 0;
    m_gpio->getPin(definition->oc2, &state);
    levels |= (state) ? 0x08 : 0;

    // disable pull-downs on oc1, oc2 pins, switch back to high impedance state
    m_gpio->configurePin(definition->oc1, GPIO_MODE_INPUT);
    m_gpio->configurePin(definition->oc2, GPIO_MODE_INPUT);

    // switch i2c bus back to peripheral mode (default setting)
    m_i2c->enableBus(I2C_ADDR(connectorId, 0), true);
    switch (levels)
    {
        case 0x00:
            // no device attached
            return E_NOT_AVAILABLE;
            break;
        case 0x03:
            // ok attached device
            break;
        case 0x0C:
            // mirrored device, i.e. wrongly connected by 180 degrees
            return E_NOT_POSSIBLE;
        default:
            // invalid device
            return E_NOT_ALLOWED;
    }

    return E_SUCCESS;
}

sr_t ShieldConnector_initialize(const ShieldConnectorDefinition_t *definition, uint8_t connectorId)
{
    RETURN_ON_ERROR(ShieldConnector_detect(definition, connectorId));

    // configure shield device enable line as output
    m_gpio->configurePin(definition->en_ldo, GPIO_MODE_OUTPUT_PUSH_PULL);

    // initially configure OC pins on connector as tristate
    m_gpio->configurePin(definition->oc1, GPIO_MODE_INPUT);
    m_gpio->configurePin(definition->oc2, GPIO_MODE_INPUT);
    m_gpio->configurePin(definition->oc3, GPIO_MODE_INPUT);
    m_gpio->configurePin(definition->oc4, GPIO_MODE_INPUT);
    // Note: there is no oc5 pind

    // set the optional LED line to tri-state
    m_gpio->configurePin(definition->oc_led, GPIO_MODE_INPUT);

    /* set gpio1 and gpio2 as input */
    m_gpio->configurePin(definition->gpio1, GPIO_MODE_INPUT);
    m_gpio->configurePin(definition->gpio2, GPIO_MODE_INPUT);

    /* Level shifter OEs are pulled high via a pull-up, so we can configure those which are enabled as input and only pull those low which are off */
    // Enable spi level shifter
    m_gpio->configurePin(definition->ls_spi_oe, GPIO_MODE_INPUT);

    /* set correct direction of GPIO level shifter and enable */
    m_gpio->configurePin(definition->ls_gpio_dir, GPIO_MODE_OUTPUT_PUSH_PULL);
    m_gpio->configurePin(definition->ls_gpio_oe, GPIO_MODE_OUTPUT_PUSH_PULL);

    /* power-up device by enabling its LDO */
    m_gpio->setPin(definition->en_ldo, true);
    this_thread_sleep_for(chrono_milliseconds(10));

    return E_SUCCESS;
}

void ShieldConnector_Constructor(IGpio *gpio, II2c *i2c)
{
    m_gpio = gpio;
    m_i2c  = i2c;
}
