/**
 * \addtogroup      CommandsAvian
 * \brief
 * Implementation of radar command interface
 * @{
 */
#ifndef COMMANDS_AVIAN_H
#define COMMANDS_AVIAN_H 1

#include <components/interfaces/ICommandsAvian.h>
#include <platform/interfaces/ISpi.h>


typedef struct _CommandsAvian CommandsAvian;
struct _CommandsAvian
{
    ICommandsAvian b_ICommandsAvian;

    ISpi *m_accessSpi;
    uint8_t m_devId;
};


void CommandsAvian_Constructor(CommandsAvian *this, ISpi *accessSpi, uint8_t devId);


sr_t CommandsAvian_execute(ICommandsAvian *this, const uint32_t commands[], uint32_t count, uint32_t results[]);
sr_t CommandsAvian_executeWrite(ICommandsAvian *this, uint32_t command);
sr_t CommandsAvian_setBits(ICommandsAvian *this, uint32_t command);


#endif /* COMMANDS_AVIAN_H */

/** @} */
