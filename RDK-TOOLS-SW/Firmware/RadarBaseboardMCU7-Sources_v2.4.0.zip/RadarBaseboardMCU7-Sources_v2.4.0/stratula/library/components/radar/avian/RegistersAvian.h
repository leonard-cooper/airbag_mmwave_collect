/**
 * \addtogroup      RegistersAvian
 * \brief
 * Implementation of radar component registers access
 * @{
 */
#ifndef REGISTERS_AVIAN_H
#define REGISTERS_AVIAN_H 1

#include <components/interfaces/ICommandsAvian.h>
#include <components/interfaces/IRegistersAvian.h>


typedef struct
{
    IRegistersAvian b_IRegisters;

    ICommandsAvian *m_commands;
} RegistersAvian;


void RegistersAvian_Constructor(RegistersAvian *this, ICommandsAvian *commands);

#endif /* REGISTERS_AVIAN_H */

/** @} */
