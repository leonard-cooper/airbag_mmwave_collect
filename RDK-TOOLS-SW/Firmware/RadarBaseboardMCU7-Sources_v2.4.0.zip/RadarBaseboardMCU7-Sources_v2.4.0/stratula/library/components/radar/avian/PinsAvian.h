/**
 * \addtogroup      PinsAvian
 * \brief
 * Implementation of radar component GPIO access
 * @{
 */
#ifndef PINS_AVIAN_H
#define PINS_AVIAN_H 1

#include <components/interfaces/IPinsAvian.h>
#include <platform/interfaces/IGpio.h>


typedef struct _PinsAvian PinsAvian;
struct _PinsAvian
{
    IPinsAvian b_IPinsAvian;

    const IPinsAvianConfig_t *m_config;
    const IGpio *m_accessGpio;
};


void PinsAvian_Constructor(PinsAvian *this, const IPinsAvianConfig_t *config, const IGpio *accessGpio);


sr_t PinsAvian_reset(IPinsAvian *this);

sr_t PinsAvian_setResetPin(IPinsAvian *this, bool state);
sr_t PinsAvian_getIrqPin(IPinsAvian *this, bool *state);

#endif /* PINS_AVIAN_H */

/** @} */
