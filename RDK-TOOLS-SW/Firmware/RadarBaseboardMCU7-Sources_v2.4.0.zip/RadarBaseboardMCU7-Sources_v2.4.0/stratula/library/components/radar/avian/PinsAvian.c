#include "PinsAvian.h"

#include <impl/thread.h>


#define IMPL ((PinsAvian *)(uintptr_t)this)


#define RESET_PULSE_WIDTH_US 1 /*!< in microseconds (100 ns according to data sheet)
                                    The RESET signal to needs to be held low for this period,
                                    and before communicating with the chip the same amount of time
                                    has to be waited after setting it to high */


sr_t PinsAvian_setResetPin(IPinsAvian *this, bool state)
{
    return IMPL->m_accessGpio->setPin(IMPL->m_config->gpioReset, state);
}

sr_t PinsAvian_getIrqPin(IPinsAvian *this, bool *state)
{
    return IMPL->m_accessGpio->getPin(IMPL->m_config->gpioIrq, state);
}

sr_t PinsAvian_reset(IPinsAvian *this)
{
    RETURN_ON_ERROR(PinsAvian_setResetPin(this, false));
    this_thread_sleep_for(chrono_microseconds(RESET_PULSE_WIDTH_US));  // T_reset
    RETURN_ON_ERROR(PinsAvian_setResetPin(this, true));
    this_thread_sleep_for(chrono_microseconds(RESET_PULSE_WIDTH_US));  // T_reset

    return E_SUCCESS;
}


void PinsAvian_Constructor(PinsAvian *this, const IPinsAvianConfig_t *config, const IGpio *accessGpio)
{
    this->b_IPinsAvian.setResetPin = PinsAvian_setResetPin;
    this->b_IPinsAvian.getIrqPin   = PinsAvian_getIrqPin;
    this->b_IPinsAvian.reset       = PinsAvian_reset;

    {
        this->m_config     = config;
        this->m_accessGpio = accessGpio;
    }

    this->m_accessGpio->configurePin(this->m_config->gpioReset, GPIO_MODE_OUTPUT_PUSH_PULL | GPIO_FLAG_OUTPUT_INITIAL_HIGH);

    // the IRQ should be triggered on the rising low-high edge, so the signal should be pulled into a defined low state,
    // so that spurious IRQs aren't generated whilst the pin is floating (i.e. during startup or whilst the BGT is in reset)
    this->m_accessGpio->configurePin(this->m_config->gpioIrq, GPIO_MODE_INPUT_PULL_DOWN);
}
