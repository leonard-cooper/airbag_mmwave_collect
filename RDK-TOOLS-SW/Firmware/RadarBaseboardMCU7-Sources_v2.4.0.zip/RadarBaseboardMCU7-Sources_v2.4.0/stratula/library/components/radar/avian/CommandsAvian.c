#include "CommandsAvian.h"

#include <impl/fatal_error.h>
#include <stddef.h>


#define IMPL ((CommandsAvian *)(uintptr_t)this)


sr_t CommandsAvian_execute(ICommandsAvian *this, const uint32_t commands[], uint32_t count, uint32_t results[])
{
    while (count--)
    {
        const uint32_t command    = *commands++;
        const uint8_t bufWrite[4] = {
            (command >> 24) & 0xFF,
            (command >> 16) & 0xFF,
            (command >> 8) & 0xFF,
            command & 0xFF,
        };
        uint8_t bufRead[4];

        RETURN_ON_ERROR(IMPL->m_accessSpi->transfer8(IMPL->m_devId, sizeof(bufWrite), bufWrite, bufRead, false));

        if (results)
        {
            *results++ = (bufRead[0] << 24) | (bufRead[1] << 16) | (bufRead[2] << 8) | bufRead[3];
        }
    }

    return E_SUCCESS;
}

sr_t CommandsAvian_executeWrite(ICommandsAvian *this, uint32_t command)
{
    return CommandsAvian_execute(this, &command, 1, NULL);
}

sr_t CommandsAvian_setBits(ICommandsAvian *this, uint32_t commandMask)
{
    uint32_t command = commandMask & AVIAN_ADDRESS_MASK;
    uint32_t value;
    RETURN_ON_ERROR(CommandsAvian_execute(this, &command, 1, &value));
    value &= AVIAN_VALUE_MASK;
    command |= I_COMMANDS_AVIAN_WRITE_BIT | value;
    command |= (commandMask & AVIAN_VALUE_MASK);
    return CommandsAvian_execute(this, &command, 1, NULL);
}

void CommandsAvian_Constructor(CommandsAvian *this, ISpi *accessSpi, uint8_t devId)
{
    this->b_ICommandsAvian.execute      = CommandsAvian_execute;
    this->b_ICommandsAvian.executeWrite = CommandsAvian_executeWrite;
    this->b_ICommandsAvian.setBits      = CommandsAvian_setBits;

    {
        this->m_accessSpi = accessSpi;
        this->m_devId     = devId;

        const uint8_t flags = SPI_MODE_0;  ///< SPI mode/configuration flags

        const uint8_t wordSize = 8;  ///< number of bits per transaction

        const uint32_t speed = 50000000;  ///< device speed
        if (this->m_accessSpi->configure(this->m_devId, flags, wordSize, speed))
        {
            fatal_error(FATAL_ERROR_SPI_CONFIG_FAILED);
        }
    }
}
