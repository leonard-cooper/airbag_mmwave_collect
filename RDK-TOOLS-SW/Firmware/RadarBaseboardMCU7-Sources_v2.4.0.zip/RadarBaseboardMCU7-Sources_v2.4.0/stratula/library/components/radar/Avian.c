#include "Avian.h"
#include <stddef.h>
#include <universal/components/implementations/radar.h>


#define IMPL        ((Avian *)(uintptr_t)this)
#define REGISTERS   ((IRegistersAvian *)&IMPL->m_registers)
#define PINS_AVIAN  ((IPinsAvian *)&IMPL->m_pins)
#define COMMANDS    ((ICommandsAvian *)&IMPL->m_commands)
#define RADAR_AVIAN (&IMPL->b_IRadarAvian)
#define RADAR       (&IMPL->b_IRadarAvian.b_IRadar)


// Register definitions
#define MAIN        0x00
#define FIFO_RESET  (1u << 3)
#define FSM_RESET   (1u << 2)
#define SW_RESET    (1u << 1)
#define FRAME_START (1u << 0)
#define CHIP_ID     0x02
#define SFCTL       0x06


/* not implemented functions */
sr_t Avian_configure(IRadar *this, const IfxRfe_MmicConfig *c);
sr_t Avian_loadSequence(IRadar *this, IfxRfe_Sequence *s);
sr_t Avian_calibrate(IRadar *this);
sr_t Avian_startSequence(IRadar *this);
sr_t Avian_getRxChannels(IRadar *this, uint8_t *number);
sr_t Avian_enableConstantFrequencyMode(IRadar *this, uint16_t txMask, float txPower);
sr_t Avian_setConstantFrequency(IRadar *this, double frequency);


IPinsAvian *Avian_getIPinsAvian(IRadarAvian *this)
{
    return PINS_AVIAN;
}

IRegistersAvian *Avian_getIRegisters(IRadarAvian *this)
{
    return REGISTERS;
}

ICommandsAvian *Avian_getICommandsAvian(IRadarAvian *this)
{
    return COMMANDS;
}

sr_t Avian_reset(IRadar *this, bool softReset)
{
    if (softReset)
    {
        RETURN_ON_ERROR(COMMANDS->setBits(COMMANDS, AVIAN_WRITE(MAIN, SW_RESET)));
    }
    else
    {
        RETURN_ON_ERROR(PINS_AVIAN->reset(PINS_AVIAN));
    }

    IMPL->m_initialized = false;

    return E_SUCCESS;
}

sr_t Avian_getDataIndex(IRadar *this, uint8_t *index)
{
    *index = IMPL->m_dataIndex;
    return E_SUCCESS;
}

sr_t Avian_initialize(IRadar *this)
{
    if (IMPL->m_initialized)
    {
        return E_SUCCESS;
    }

    //    if (IMPL->m_properties->qspiWaitCycles > 15)
    //    {
    //        return E_INVALID_PARAMETER;
    //    }
    //
    //    // first of all, high speed compensation and QSPI wait cycles have to be configured
    //    const uint32_t spiConfig = AVIAN_WRITE(SFCTL,
    //                                           ((IMPL->m_properties->qspiWaitCycles - 1) << 20) | (IMPL->m_properties->highSpeedCompensation << 16));
    //    RETURN_ON_ERROR(COMMANDS->execute(COMMANDS, &spiConfig, 1, NULL));

    IMPL->m_initialized = true;

    return E_SUCCESS;
}

sr_t Avian_configure(IRadar *this, const IfxRfe_MmicConfig *c)
{
    return E_NOT_IMPLEMENTED;
}

sr_t Avian_loadSequence(IRadar *this, IfxRfe_Sequence *s)
{
    return E_NOT_IMPLEMENTED;
}

sr_t Avian_calibrate(IRadar *this)
{
    return E_NOT_IMPLEMENTED;
}

sr_t Avian_startSequence(IRadar *this)
{
    return E_NOT_IMPLEMENTED;
}

sr_t Avian_startData(IRadar *this)
{
    RETURN_ON_ERROR(IMPL->m_accessData->start(IMPL->m_dataIndex));

    return COMMANDS->setBits(COMMANDS, AVIAN_WRITE(MAIN, FRAME_START));
}

sr_t Avian_stopData(IRadar *this)
{
    RETURN_ON_ERROR(COMMANDS->setBits(COMMANDS, AVIAN_WRITE(MAIN, FIFO_RESET | FSM_RESET)));

    return IMPL->m_accessData->stop(IMPL->m_dataIndex);
}

sr_t Avian_getRxChannels(IRadar *this, uint8_t *number)
{
    return E_NOT_IMPLEMENTED;
}

sr_t Avian_enableConstantFrequencyMode(IRadar *this, uint16_t txMask, float txPower)
{
    return E_NOT_IMPLEMENTED;
}

sr_t Avian_setConstantFrequency(IRadar *this, double frequency)
{
    return E_NOT_IMPLEMENTED;
}


void Avian_Constructor(Avian *this, IData *accessData, IGpio *accessGpio, ISpi *accessSpi, const BoardRadarConfig_t *boardConfig, const IPinsAvianConfig_t *pinsAvianConfig)
{
    this->b_IRadarAvian.b_IRadar.m_bImplementation = COMPONENT_IMPL_RADAR_AVIAN;

    CommandsAvian_Constructor(&this->m_commands, accessSpi, boardConfig->devId);
    RegistersAvian_Constructor(&this->m_registers, COMMANDS);
    PinsAvian_Constructor(&this->m_pins, pinsAvianConfig, accessGpio);

    // IRadar (high level interface)
    this->b_IRadarAvian.b_IRadar.reset                       = Avian_reset;
    this->b_IRadarAvian.b_IRadar.getDataIndex                = Avian_getDataIndex;
    this->b_IRadarAvian.b_IRadar.initialize                  = Avian_initialize;
    this->b_IRadarAvian.b_IRadar.configure                   = Avian_configure;
    this->b_IRadarAvian.b_IRadar.loadSequence                = Avian_loadSequence;
    this->b_IRadarAvian.b_IRadar.calibrate                   = Avian_calibrate;
    this->b_IRadarAvian.b_IRadar.startSequence               = Avian_startSequence;
    this->b_IRadarAvian.b_IRadar.startData                   = Avian_startData;
    this->b_IRadarAvian.b_IRadar.stopData                    = Avian_stopData;
    this->b_IRadarAvian.b_IRadar.getRxChannels               = Avian_getRxChannels;
    this->b_IRadarAvian.b_IRadar.enableConstantFrequencyMode = Avian_enableConstantFrequencyMode;
    this->b_IRadarAvian.b_IRadar.setConstantFrequency        = Avian_setConstantFrequency;


    // IRadarAvian (low level interface)
    this->b_IRadarAvian.getIRegisters     = Avian_getIRegisters;
    this->b_IRadarAvian.getIPinsAvian     = Avian_getIPinsAvian;
    this->b_IRadarAvian.getICommandsAvian = Avian_getICommandsAvian;

    this->m_accessData  = accessData;
    this->m_dataIndex   = boardConfig->dataIndex;
    this->m_initialized = false;

    // perform reset because device is at undefined state after power-up
    const bool softReset = false;
    RADAR->reset(RADAR, softReset);
}
