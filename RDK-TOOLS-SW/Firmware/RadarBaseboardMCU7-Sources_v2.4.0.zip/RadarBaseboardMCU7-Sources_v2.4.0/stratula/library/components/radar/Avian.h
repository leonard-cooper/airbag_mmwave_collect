/**
 * \addtogroup      Avian
 * \brief
 * Implementation of Avian radar component
 * @{
 */
#ifndef AVIAN_H
#define AVIAN_H 1

#include <stdbool.h>
#include <stdint.h>

#include "avian/CommandsAvian.h"
#include "avian/PinsAvian.h"
#include "avian/RegistersAvian.h"
#include <components/interfaces/IRadarAvian.h>
#include <platform/interfaces/IData.h>


typedef struct _Avian Avian;

void Avian_Constructor(Avian *this, IData *accessData, IGpio *accessGpio, ISpi *accessSpi, const BoardRadarConfig_t *boardConfig, const IPinsAvianConfig_t *pinsAvianConfig);

//IRadar
sr_t Avian_reset(IRadar *this, bool softReset);
sr_t Avian_initialize(IRadar *this);
sr_t Avian_getDataIndex(IRadar *this, uint8_t *index);
sr_t Avian_startData(IRadar *this);
sr_t Avian_stopData(IRadar *this);

//IRadarAvian
IRegistersAvian *Avian_getIRegisters(IRadarAvian *this);
IPinsAvian *Avian_getIPinsAvian(IRadarAvian *this);
ICommandsAvian *Avian_getICommandsAvian(IRadarAvian *this);


struct _Avian
{
    IRadarAvian b_IRadarAvian;

    RegistersAvian m_registers;
    PinsAvian m_pins;
    CommandsAvian m_commands;

    IData *m_accessData;
    uint8_t m_dataIndex;

    bool m_initialized;

    /** \private @{ */
    /** @} */
};

/** @} */


#endif /* AVIAN_H */
