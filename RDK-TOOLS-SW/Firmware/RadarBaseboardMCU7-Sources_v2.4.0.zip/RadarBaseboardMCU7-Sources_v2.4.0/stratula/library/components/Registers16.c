#include "Registers16.h"

#define RegistersType Registers16

#include "Registers.inc"
