/**
 * \internal
 * \addtogroup      Registers
 * \brief
 * Base implementation of device registers access
 * \endinternal
 * @{
 */
#ifndef REGISTERS_16_H
#define REGISTERS_16_H 1


#include <components/interfaces/IRegisters16.h>


typedef struct _Registers_uint16_t Registers16;
struct _Registers_uint16_t
{
    IRegistersType b_IRegisters;

    RegType m_increment;
};


void Registers16_Constructor(Registers16 *this, RegType increment);

#endif /* REGISTERS_16_H */

/** @} */
