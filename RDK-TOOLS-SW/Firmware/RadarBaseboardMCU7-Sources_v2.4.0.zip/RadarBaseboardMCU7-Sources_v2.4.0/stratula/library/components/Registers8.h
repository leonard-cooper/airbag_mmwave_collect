/**
 * \internal
 * \addtogroup      Registers
 * \brief
 * Base implementation of device registers access
 * \endinternal
 * @{
 */
#ifndef REGISTERS_8_H
#define REGISTERS_8_H 1


#include <components/interfaces/IRegisters8.h>


typedef struct _Registers_uint8_t Registers8;
struct _Registers_uint8_t
{
    IRegistersType b_IRegisters;

    RegType m_increment;
};


void Registers8_Constructor(Registers8 *this, RegType increment);

#endif /* REGISTERS_8_H */

/** @} */
