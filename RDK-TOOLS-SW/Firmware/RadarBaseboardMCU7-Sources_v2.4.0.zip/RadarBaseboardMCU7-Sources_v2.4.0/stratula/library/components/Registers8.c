#include "Registers8.h"

#define RegistersType Registers8

#include "Registers.inc"
