/**
 * \internal
 * \addtogroup      Registers
 * \brief
 * Base implementation of device registers access
 * \endinternal
 * @{
 */
#ifndef REGISTERS_32_H
#define REGISTERS_32_H 1


#include <components/interfaces/IRegisters32.h>


typedef struct _Registers_uint32_t Registers32;
struct _Registers_uint32_t
{
    IRegistersType b_IRegisters;

    RegType m_increment;
};


void Registers32_Constructor(Registers32 *this, RegType increment);

#endif /* REGISTERS_32_H */

/** @} */
