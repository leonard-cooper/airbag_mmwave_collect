/**
 * \addtogroup      IRegisters
 * \brief
 * Device registers access interface
 * @{
 */
//#ifndef I_REGISTERS_H
//#define I_REGISTERS_H 1

#include <common/errors.h>
#include <stdbool.h>
#include <stdint.h>


#define COMBINE_X(a, b) a##b
#define COMBINE(a, b)   COMBINE_X(a, b)


#define _IRegistersType COMBINE(_IRegisters_, RegType)
#define IRegistersType  COMBINE(IRegisters_, RegType)


typedef struct _IRegistersType IRegistersType;
struct _IRegistersType
{
    /**
    * Reads device register value.
    *
    * @param regAddr register address
    * @param readData address to store the read data to
    * @return Strata error code
    * @return error code
    */
    sr_t (*read)(IRegistersType *this, RegType regAddr, RegType *readData);

    /**
    * Writes value to device register address.
    *
    * @param regAddr register address
    * @param value register value
    * @return Strata error code
    */
    sr_t (*write)(IRegistersType *this, RegType regAddr, RegType value);

    /**
    * Reads a sequence of consecutive device register values from an initial start address.
    *
    * @param regAddr initial register address
    * @param count number of register values to be read
    * @param values receives sequence of register values
    * @return Strata error code
    */
    sr_t (*readBurst)(IRegistersType *this, RegType regAddr, RegType count, RegType values[]);

    /**
    * Writes a sequence of consecutive device register values from an initial start address.
    *
    * @param regAddr initial register address
    * @param count number of register values to be written
    * @param values sequence of register values
    * @return Strata error code
    */
    sr_t (*writeBurst)(IRegistersType *this, RegType regAddr, RegType count, const RegType values[]);

    /**
    * Writes a sequence of different device register values to their respective addresses.
    *
    * @param regVals sequence of register address and value pairs
    * @param count number of register values to be written
    * @return Strata error code
    */
    sr_t (*writeBatch)(IRegistersType *this, const RegType regVals[][2], RegType count);

    /**
    * Sets specific bits on a device register.
    *
    * @param regAddr register address
    * @param bitmask bitmask to be set
    * @return Strata error code
    */
    sr_t (*setBits)(IRegistersType *this, RegType regAddr, RegType bitmask);

    /**
    * Clears specific bits on a device register.
    *
    * @param regAddr register address
    * @param bitmask bitmask to be cleared
    * @return Strata error code
    */
    sr_t (*clearBits)(IRegistersType *this, RegType regAddr, RegType bitmask);

    /**
    * Modifies specific bits on a device register.
    * clearBitmask takes precedence over setBitmask!
    *
    * @param regAddr register address
    * @param clearBitmask bitmask to be cleared (done first)
    * @param setBitmask bitmask to be set (done second)
    * @return Strata error code
    */
    sr_t (*modifyBits)(IRegistersType *this, RegType regAddr, RegType clearBitmask, RegType setBitmask);
};


//#endif /* I_REGISTERS_H */

/** @} */
