/**
 * \addtogroup      ICommandsAvian
 * \brief
 * Radar component command interface
 * @{
 */

#ifndef I_COMMANDS_AVIAN_H
#define I_COMMANDS_AVIAN_H 1

#include <common/errors.h>
#include <stdint.h>


#define I_COMMANDS_AVIAN_VALUE_WIDTH    24u
#define I_COMMANDS_AVIAN_ADDRESS_WIDTH  7u
#define I_COMMANDS_AVIAN_ADDRESS_OFFSET (I_COMMANDS_AVIAN_VALUE_WIDTH + 1)
#define I_COMMANDS_AVIAN_WRITE_BIT      (1u << I_COMMANDS_AVIAN_VALUE_WIDTH)


#define AVIAN_VALUE_MASK            ((1u << I_COMMANDS_AVIAN_VALUE_WIDTH) - 1)
#define AVIAN_ADDRESS_MASK          (((1u << I_COMMANDS_AVIAN_ADDRESS_WIDTH) - 1) << I_COMMANDS_AVIAN_ADDRESS_OFFSET);
#define AVIAN_READ(address)         (address << I_COMMANDS_AVIAN_ADDRESS_OFFSET)
#define AVIAN_WRITE(address, value) (((address) << I_COMMANDS_AVIAN_ADDRESS_OFFSET) | I_COMMANDS_AVIAN_WRITE_BIT | ((value)&AVIAN_VALUE_MASK))


typedef struct _ICommandsAvian ICommandsAvian;
struct _ICommandsAvian
{
    /**
    * Executes a list of commands. If results is not NULL, the return values are provided.
    */
    sr_t (*execute)(ICommandsAvian *this, const uint32_t commands[], uint32_t count, uint32_t results[]);

    /**
    * Executes a single write command.
    */
    sr_t (*executeWrite)(ICommandsAvian *this, uint32_t command);

    /**
    * Sets a mask of bits at a given address
    */
    sr_t (*setBits)(ICommandsAvian *this, uint32_t commandMask);
};

#endif  // I_COMMANDS_AVIAN_H
