/**
 * \addtogroup      IRegisters
 * \brief
 * Device registers access interface
 * @{
 */
#ifndef I_REGISTERS_8_H
#define I_REGISTERS_8_H 1

#ifdef RegType
#undef RegType
#endif

#define RegType uint8_t

#include "IRegisters.h"

typedef IRegisters_uint8_t IRegisters8;

#endif /* I_REGISTERS_8_H */

/** @} */
