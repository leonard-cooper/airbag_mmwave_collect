/**
 * \addtogroup      IRegisters
 * \brief
 * Device registers access interface
 * @{
 */
#ifndef I_REGISTERS_32_H
#define I_REGISTERS_32_H 1

#ifdef RegType
#undef RegType
#endif

#define RegType uint32_t

#include "IRegisters.h"

typedef IRegisters_uint32_t IRegisters32;

#endif /* I_REGISTERS_32_H */

/** @} */
