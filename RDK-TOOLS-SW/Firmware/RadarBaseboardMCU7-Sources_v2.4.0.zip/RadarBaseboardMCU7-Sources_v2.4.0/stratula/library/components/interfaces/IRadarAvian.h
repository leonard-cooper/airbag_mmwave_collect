/**
 * \addtogroup      IRadarAvian
 * \brief
 * Radar component access interface
 * @{
 */
#ifndef I_RADAR_AVIAN_H
#define I_RADAR_AVIAN_H 1

#include <components/interfaces/ICommandsAvian.h>
#include <components/interfaces/IPinsAvian.h>
#include <components/interfaces/IRadar.h>
#include <components/interfaces/IRegistersAvian.h>


/**
 * \brief Access interface to a radar front end device of the Avian family,
 * e.g. BGT60TR13C, BGT60ATR24C, BGT60TR13D and BGT60TR12E.
 */
typedef struct _IRadarAvian IRadarAvian;
struct _IRadarAvian
{
    IRadar b_IRadar;

    IRegistersAvian *(*getIRegisters)(IRadarAvian *this);
    IPinsAvian *(*getIPinsAvian)(IRadarAvian *this);
    ICommandsAvian *(*getICommandsAvian)(IRadarAvian *this);
};


#endif /* I_RADAR_AVIAN_H */

/** @} */
