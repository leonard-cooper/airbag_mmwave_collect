/**
 * \addtogroup      IRegisters
 * \brief
 * Device registers access interface
 * @{
 */
#ifndef I_REGISTERS_16_H
#define I_REGISTERS_16_H 1

#ifdef RegType
#undef RegType
#endif

#define RegType uint16_t

#include "IRegisters.h"

typedef IRegisters_uint16_t IRegisters16;

#endif /* I_REGISTERS_16_H */

/** @} */
