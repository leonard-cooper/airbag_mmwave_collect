#include "Module.h"
#include <stddef.h>

#include <impl/timer.h>


extern LedDefinition_t ledMeasuring;
extern LedDefinition_t ledTransferring;


static void Module_triggerMeasurement(Module *this)
{
    this->m_doMeasurementAfterData = false;

    IModule *derived = this->m_derived;
    derived->doMeasurement(derived);
}

static void Module_timerCallback(void *arg)
{
    Module *this = (Module *)arg;

    if (this->m_currentState == MODULE_MEASURING)
    {
        this->m_doMeasurementAfterData = true;
    }
    else
    {
        Module_triggerMeasurement(this);
    }
}

void Module_dataCallback(void *arg, uint32_t data[][2], uint8_t count, uint8_t channel, uint64_t timestamp)
{
    Module *this = (Module *)arg;

    Led_set(this->m_ledMeasuring, false);

    if (this->m_dataCallback != NULL)
    {
        Led_set(this->m_ledMeasuring, false);
        Led_set(this->m_ledTransferring, true);
        this->m_dataCallback(this->m_dataCallbackArg, data, count, channel, timestamp);
        Led_set(this->m_ledTransferring, false);
    }

    //If it has not been stopped, check if this is the last channel of one measurement
    if (this->m_currentState != MODULE_STOPPED)
    {
        if ((this->m_lastChannel == 0) || (this->m_lastChannel == channel))
        {
            // check if it is time to directly trigger a new measurement,
            this->m_currentState = MODULE_READY;
            if (this->m_doMeasurementAfterData)
            {
                Module_triggerMeasurement(this);
            }
        }
    }
}

void Module_registerDataCallback(Module *this, IProcessing_DataCallback dataCallback, void *arg)
{
    this->m_dataCallback    = dataCallback;
    this->m_dataCallbackArg = arg;
}

void Module_configure(Module *this, uint8_t measurementMode, uint8_t lastChannel)
{
    this->m_currentState    = MODULE_STOPPED;
    this->m_measurementMode = measurementMode;
    this->m_lastChannel     = lastChannel;
}

void Module_reset(Module *this)
{
    Module_stopMeasurements(this);
    this->m_currentState = MODULE_UNCONFIGURED;
}

sr_t Module_startMeasurements(Module *this, double measurementCycle)
{
    if (this->m_currentState == MODULE_UNCONFIGURED)
    {
        return E_NOT_POSSIBLE;
    }
    else if (this->m_currentState == MODULE_STOPPED)
    {
        this->m_currentState = MODULE_READY;
    }

    switch (this->m_measurementMode)
    {
        case MEASUREMENT_MODE_TIMER:
            if (measurementCycle == 0)
            {
                Timer_stop(this->m_timerId);
            }
            else
            {
                Timer_start(this->m_timerId, chrono_milliseconds(measurementCycle * 1000));
            }
            break;
        case MEASUREMENT_MODE_MANUAL:
        case MEASUREMENT_MODE_CONTINUOUS:
            break;
        default:
            return E_UNEXPECTED_VALUE;
    }
    return E_SUCCESS;
}

void Module_stopMeasurements(Module *this)
{
    if (this->m_currentState == MODULE_STOPPED)
    {
        return;
    }

    Led_set(this->m_ledMeasuring, false);
    if (this->m_measurementMode == MEASUREMENT_MODE_TIMER)
    {
        Timer_stop(this->m_timerId);
        this->m_doMeasurementAfterData = false;
    }
    this->m_currentState = MODULE_STOPPED;
}

sr_t Module_doMeasurement(Module *this)
{
    if (this->m_currentState != MODULE_READY)
    {
        return E_NOT_AVAILABLE;
    }
    this->m_currentState = MODULE_MEASURING;
    Led_set(this->m_ledMeasuring, true);
    return E_SUCCESS;
}

void Module_Constructor(Module *this, IModule *derived)
{
    this->m_derived         = derived;
    this->m_currentState    = MODULE_UNCONFIGURED;
    this->m_measurementMode = MEASUREMENT_MODE_MANUAL;
    this->m_dataCallback    = NULL;

    this->m_doMeasurementAfterData = false;
    this->m_lastChannel            = 0;

    this->m_ledMeasuring    = &ledMeasuring;
    this->m_ledTransferring = &ledTransferring;
    Led_initialize(this->m_ledMeasuring);
    Led_initialize(this->m_ledTransferring);

    this->m_timerId = Timer_add();
    Timer_setCallback(this->m_timerId, Module_timerCallback, this);
}
