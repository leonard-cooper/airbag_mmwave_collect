/**
 * \addtogroup        RadarModuleInterface
 * @{
 */
#ifndef I_MODULE_RADAR_H
#define I_MODULE_RADAR_H 1

#include <modules/interfaces/IModule.h>
#include <platform/interfaces/IProcessingRadar.h>
#include <universal/data_definitions.h>
#include <universal/types/IfxRfe_Types.h>
#include <universal/types/IfxRsp_Types.h>

typedef struct _IModuleRadar IModuleRadar;

struct _IModuleRadar
{
    IModule b_IModule;

    /**
     * Get measurement input information
     *
     * @param info pointer to the memory structure where to store the information
     * @return Strata error code
     */
    sr_t (*getDataProperties)(IModuleRadar *this, IDataProperties_t *props);
    sr_t (*getRadarInfo)(IModuleRadar *this, IProcessingRadarInput_t *info, const IDataProperties_t *dataProperties);


    IfxRfe_MmicConfig *(*getConfiguration)(IModuleRadar *this);
    IfxRfe_Sequence *(*getSequence)(IModuleRadar *this);
    IfxRsp_Stages *(*getProcessingStages)(IModuleRadar *this);
    IfxRsp_AntennaCalibration *(*getCalibration)(IModuleRadar *this);

    sr_t (*setConfiguration)(IModuleRadar *this, const IfxRfe_MmicConfig *c);
    sr_t (*setSequence)(IModuleRadar *this, const IfxRfe_Sequence *s);
    sr_t (*setProcessingStages)(IModuleRadar *this, const IfxRsp_Stages *s);
    sr_t (*setCalibration)(IModuleRadar *this, const IfxRsp_AntennaCalibration c[2]);
};


#endif /* I_MODULE_RADAR_H */
/** @} */
