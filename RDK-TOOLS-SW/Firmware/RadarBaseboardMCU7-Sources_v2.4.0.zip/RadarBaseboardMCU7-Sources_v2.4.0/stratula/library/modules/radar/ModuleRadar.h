#ifndef MODULE_RADAR_H
#define MODULE_RADAR_H 1

#include <modules/Module.h>
#include <modules/interfaces/IModuleRadar.h>


#define MODULE       (&IMPL->base.base)
#define MODULE_RADAR ((IModuleRadar *)(uintptr_t)this)


typedef struct _ModuleRadar ModuleRadar;


void ModuleRadar_Constructor(ModuleRadar *this, IfxRfe_MmicConfig *mmicConfig, IfxRfe_Sequence *sequence,
                             IfxRsp_Stages *processingStages, IfxRsp_AntennaCalibration *calibration);

sr_t ModuleRadar_setConfiguration(IModuleRadar *this, const IfxRfe_MmicConfig *c);
sr_t ModuleRadar_setSequence(IModuleRadar *this, const IfxRfe_Sequence *s);
sr_t ModuleRadar_setProcessingStages(IModuleRadar *this, const IfxRsp_Stages *s);
sr_t ModuleRadar_setCalibration(IModuleRadar *this, const IfxRsp_AntennaCalibration c[2]);


struct _ModuleRadar
{
    IModuleRadar b_IModuleRadar;

    Module base;

    IfxRfe_MmicConfig *m_mmicConfig;
    IfxRfe_Sequence *m_sequence;
    IfxRsp_Stages *m_processingStages;
    IfxRsp_AntennaCalibration *m_calibration;
};


#endif /* MODULE_RADAR_H */
