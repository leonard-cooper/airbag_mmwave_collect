#ifndef STATIC_ASSERT_H
#define STATIC_ASSERT_H

#define STATIC_ASSERT(pred, msg) typedef int STATIC_ASSERT_##msg[pred ? 1 : -1];


#endif  // STATIC_ASSERT_H