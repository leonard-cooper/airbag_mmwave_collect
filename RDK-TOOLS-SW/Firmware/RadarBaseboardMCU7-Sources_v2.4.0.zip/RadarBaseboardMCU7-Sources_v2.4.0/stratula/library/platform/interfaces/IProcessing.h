/**
 * \addtogroup      IProcessing
 * @{
 */
#ifndef IPROCESSING_H
#define IPROCESSING_H 1

#include <stdint.h>


typedef void (*IProcessing_DataCallback)(void *arg, uint32_t data[][2], uint8_t count, uint8_t channel, uint64_t timestamp);


#endif /* IPROCESSING_H */

/** @} */
