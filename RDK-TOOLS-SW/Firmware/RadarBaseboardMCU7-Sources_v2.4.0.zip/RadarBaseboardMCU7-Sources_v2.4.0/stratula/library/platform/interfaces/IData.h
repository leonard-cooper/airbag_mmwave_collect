/**
 * \addtogroup      IData
 * \brief
 * This is an interface supporting radar-data access, as specified by IData_Settings
 * @{
 */
#ifndef IDATA_H
#define IDATA_H 1

#include <common/errors.h>
#include <stdbool.h>
#include <stdint.h>
#include <universal/data_definitions.h>


typedef struct
{
    /**
     * Informs whether calibration is required for a certain data rate
     *
     * @param index data interface index
     * @param dataRate data rate in bits per second
     * @param isRequired out parameter to store the result
     * @return Strata error code
     */
    sr_t (*calibrationRequired)(uint8_t index, double dataRate, bool *isRequired);

    /**
     * Performs calibration routine on data interface
     *
     * @param index data interface index
     * @return Strata error code
     */
    sr_t (*calibrate)(uint8_t index);

    /**
     * Configures the data interface to continuously receive the described data
     * This can be repeated with different configurations
     *
     * @param index data interface index
     * @param *dataProperties pointer to memory structure containing the configuration
     * @return Strata error code
     */
    sr_t (*configure)(uint8_t index, const IDataProperties_t *dataProperties, const IDataSettings_t *dataSettings);

    /**
     * Starts the data interface
     *
     * @param index data interface index
     * @return Strata error code
     */
    sr_t (*start)(uint8_t index);

    /**
     * Stops the data interface
     *
     * @param index data interface index
     * @return Strata error code
     */
    sr_t (*stop)(uint8_t index);

    /**
     * Return the CRC error status from the last execution
     *
     * @param index data interface index
     * @param flag out parameter for the result: true if there has been a CRC error, otherwise false
     * @return Strata error code
     */
    sr_t (*getStatusFlags)(uint8_t index, uint32_t *flags);

    sr_t (*registerCallback)(IData_callback callback, void *arg);
} IData;

#endif /* IDATA_H */
/** @} */
