#include "Led.h"

#include <impl/PlatformGpio.h>
#include <stddef.h>


sr_t Led_initialize(const LedDefinition_t *led)
{
    if (led == NULL)
    {
        return E_SUCCESS;
    }

    const uint8_t flags = led->activeLow ? (GPIO_MODE_OUTPUT_OPEN_DRAIN | GPIO_FLAG_OUTPUT_INITIAL_HIGH) : GPIO_MODE_OUTPUT_OPEN_SOURCE;
    return PlatformGpio_configurePin(led->gpio, flags);
}

sr_t Led_set(const LedDefinition_t *led, bool state)
{
    if (led == NULL)
    {
        return E_SUCCESS;
    }

    return PlatformGpio_setPin(led->gpio, state ^ led->activeLow);
}
