#include "../getMac.h"
#include "../getUuid.h"

#include "../24aa02xuid.h"
//#include "../getUuidFromMac.h"


#include <BoardDefinition.h>


// the following definitions are selected by including this header once in the project
// the linker will complain if multiple implementations are included


sr_t getUuid(uint8_t uuid[UUID_LENGTH])
{
#ifdef BOARD_EEPROM_ADDRESS_24AA02XUID
    return _24aa02xuuid_getUuid(BOARD_EEPROM_ADDRESS_24AA02XUID, uuid);
//#elseif
//    return getUuidFromMac(uuid);
#else
    return E_NOT_IMPLEMENTED;
#endif
}

sr_t getMac(uint8_t mac[MAC_LENGTH])
{
#ifdef BOARD_EEPROM_ADDRESS_24AA02XUID
    return _24aa02xuuid_getMac(BOARD_EEPROM_ADDRESS_24AA02XUID, mac);
#else
    return E_NOT_IMPLEMENTED;
#endif
}
