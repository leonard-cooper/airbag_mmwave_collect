#ifndef _24AA02XUUID_H
#define _24AA02XUUID_H 1

#include "getMac.h"
#include "getUuid.h"

sr_t _24aa02xuuid_getMac(uint8_t devAddr, uint8_t mac[MAC_LENGTH]);
sr_t _24aa02xuuid_getUuid(uint8_t devAddr, uint8_t uuid[UUID_LENGTH]);

#endif /* _24AA02XUUID_H */
