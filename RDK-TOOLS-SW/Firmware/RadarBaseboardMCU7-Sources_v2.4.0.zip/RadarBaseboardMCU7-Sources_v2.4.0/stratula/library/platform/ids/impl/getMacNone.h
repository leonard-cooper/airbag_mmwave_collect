#include "../getMac.h"


// this definition is selected by including this header once in the project
// the linker will complain if multiple implementations are included
sr_t getMac(uint8_t mac[MAC_LENGTH])
{
    return E_NOT_IMPLEMENTED;
}
