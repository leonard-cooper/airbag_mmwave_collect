# Firmware for RadarBaseboardMCU7

To compile the firmware change to the directory
targets/atmel/subprojects/RadarBaseboardMCU7 and open the Atmel Studio
solution. You can also use the makefiles to compile the source code.

